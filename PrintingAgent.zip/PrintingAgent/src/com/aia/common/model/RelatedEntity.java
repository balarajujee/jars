package com.aia.common.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelatedEntity", propOrder = {
    "name", "address", "sharePercent", "idNo", "dateOfBirth", "relationship"
})
@XmlRootElement(name = "RelatedEntity")
public class RelatedEntity {
	@XmlElement(required = true) private String name;
	@XmlElement(required = true) private String address;
	@XmlElement(required = true) private BigDecimal sharePercent;
	@XmlElement(required = true) private String idNo;
	@XmlElement(required = true) private Date dateOfBirth;
	@XmlElement(required = true) private String relationship;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigDecimal getSharePercent() {
		return sharePercent;
	}

	public void setSharePercent(BigDecimal sharePercent) {
		this.sharePercent = sharePercent;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
}