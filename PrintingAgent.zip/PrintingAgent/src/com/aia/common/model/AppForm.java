package com.aia.common.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AppForm", propOrder = {
    "policyNo", "insuredName", "mykadNo", "dateOfBirth", "gender", 
    "nationality", "occupation", "address", "postcode", "telNo",
    "height", "weight", "plans", "qIsSmoke", "qCigaretteNo",
    "qIsCriticalIllness", "qIsSymptoms", "qIsDefects", "qIsInsAccept",
    "nominees", "trustees", "isReceiveInfo", "polLanguage","modeOfPayment",
    "paymentType","paymentTypeWord","EmployerName" ,"email","qIsFemaleQ"
})
@XmlRootElement(name = "AppForm")
public class AppForm {
	@XmlElement(required = true) private String policyNo;
	@XmlElement(required = true) private String insuredName;
	@XmlElement(required = true) private String mykadNo;
	@XmlElement(required = true) private Date dateOfBirth;
	@XmlElement(required = true) private String gender;
	@XmlElement(required = true) private String nationality;
	@XmlElement(required = true) private String occupation;
	@XmlElement(required = true) private String address;
	@XmlElement(required = true) private String postcode;
	@XmlElement(required = true) private String telNo;
	@XmlElement(required = true) private Float height;
	@XmlElement(required = true) private Float weight;
	
	@XmlElement(required = true) private String planName;
	@XmlElement(required = true) private BigDecimal sumAssured;
	
	@XmlElement(required = true) private String qIsSmoke;
	@XmlElement(required = true) private Integer qCigaretteNo;
	@XmlElement(required = true) private String qIsCriticalIllness;
	@XmlElement(required = true) private String qIsSymptoms;
	@XmlElement(required = true) private String qIsDefects;
	@XmlElement(required = true) private String qIsInsAccept;
	@XmlElement(required = true) private String qIsFemaleQ;
	
	@XmlElement(required = true) private List<RelatedEntity> nominees;
	@XmlElement(required = true) private List<RelatedEntity> trustees;
	
	@XmlElement(required = true) private String isReceiveInfo;
	@XmlElement(required = true) private String polLanguage;
	@XmlElement(required = true) private String modeOfPayment;
	@XmlElement(required = true) private String paymentType;
	@XmlElement(required = true) private String paymentTypeWord;
	@XmlElement(required = true) private String EmployerName;
	@XmlElement(required = true) private String email;
	
	public String getPaymentTypeWord() {
		return paymentTypeWord;
	}

	public void setPaymentTypeWord(String paymentTypeWord) {
		this.paymentTypeWord = paymentTypeWord;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	private String policyId;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getMykadNo() {
		return mykadNo;
	}

	public void setMykadNo(String mykadNo) {
		this.mykadNo = mykadNo;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public Float getHeight() {
		return height;
	}

	public void setHeight(Float height) {
		this.height = height;
	}

	public Float getWeight() {
		return weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getqIsSmoke() {
		return qIsSmoke;
	}

	public void setqIsSmoke(String qIsSmoke) {
		this.qIsSmoke = qIsSmoke;
	}

	public Integer getqCigaretteNo() {
		return qCigaretteNo;
	}

	public void setqCigaretteNo(Integer qCigaretteNo) {
		this.qCigaretteNo = qCigaretteNo;
	}

	public String getqIsCriticalIllness() {
		return qIsCriticalIllness;
	}

	public void setqIsCriticalIllness(String qIsCriticalIllness) {
		this.qIsCriticalIllness = qIsCriticalIllness;
	}

	public String getqIsSymptoms() {
		return qIsSymptoms;
	}

	public void setqIsSymptoms(String qIsSymptoms) {
		this.qIsSymptoms = qIsSymptoms;
	}

	public String getqIsDefects() {
		return qIsDefects;
	}

	public void setqIsDefects(String qIsDefects) {
		this.qIsDefects = qIsDefects;
	}

	public String getqIsInsAccept() {
		return qIsInsAccept;
	}

	public void setqIsInsAccept(String qIsInsAccept) {
		this.qIsInsAccept = qIsInsAccept;
	}

	public List<RelatedEntity> getNominees() {
		return nominees;
	}

	public void setNominees(List<RelatedEntity> nominees) {
		this.nominees = nominees;
	}

	public List<RelatedEntity> getTrustees() {
		return trustees;
	}

	public void setTrustees(List<RelatedEntity> trustees) {
		this.trustees = trustees;
	}

	public String getIsReceiveInfo() {
		return isReceiveInfo;
	}

	public void setIsReceiveInfo(String isReceiveInfo) {
		this.isReceiveInfo = isReceiveInfo;
	}

	public String getPolLanguage() {
		return polLanguage;
	}

	public void setPolLanguage(String polLanguage) {
		this.polLanguage = polLanguage;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public BigDecimal getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(BigDecimal sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public String getEmployerName() {
		return EmployerName;
	}

	public void setEmployerName(String employerName) {
		EmployerName = employerName;
	}

	public String getqIsFemaleQ() {
		return qIsFemaleQ;
	}

	public void setqIsFemaleQ(String qIsFemaleQ) {
		this.qIsFemaleQ = qIsFemaleQ;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}