package com.aia.pdfGenerator.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

import com.aia.common.db.DBCommon;
import com.aia.pdfGenerator.model.Footer;
import com.aia.pdfGenerator.model.Header;
import com.aia.pdfGenerator.model.Margin;
import com.aia.pdfGenerator.model.Reports;
import com.aia.pdfGenerator.model.Table;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

public class GenericHeaderFooter extends GenericUtil {
	private static DBCommon dr = new DBCommon();
	
	/**
	 * set the document detail (page size, margin, title, author, subject)
	 * @return Document doc
	 */
	public Document initDoc() {
		Document doc;
		Rectangle rect;
		
		// set page size
		if(getReportDefinition().getPageSize().equals(defaultPaperSize)) {
			rect = PageSize.LETTER;
		} else {
			rect = PageSize.A4;
		}
		
		// set page layout
		if(getReportDefinition().getPageLayout().equals(defaultPageLayout)) {
			doc = new Document(rect);
		} else {
			doc = new Document(rect.rotate());
		}
		
		// set report margin
		Margin margin = getReportDefinition().getMargin();
		
		if(margin == null) {
			doc.setMargins(10, 10, 100, 10);
		} else {
			doc.setMargins(margin.getMarginleft(), margin.getMarginright(), margin.getMargintop(), margin.getMarginbottom());
		}
		
		// add meta information to the report
		doc.addTitle(getReportDefinition().getTitle());
		doc.addAuthor(getReportDefinition().getAuthor());
//		doc.addSubject(getReportDefinition().getSubject());
		
		return doc;
	}
	
	/**
	 * write the report header to the PDF file
	 * @param writer
	 * @param document
	 * @throws DocumentException
	 */
	public void printHeader(Document doc, Reports reportDefinition) throws DocumentException, IOException {
		Header header = reportDefinition.getHeader();
		
		PdfPTable headerTable = null;
		if(header != null && header.getTable() != null && header.getTable().size() > 0) {
			for (Table table : header.getTable()) {
				headerTable = genPDFPTable(doc, headerTable, table);				
			}
			float top = doc.getPageSize().getHeight() - doc.topMargin() + headerTable.getTotalHeight();
			
			ColumnText column = new ColumnText(writer.getDirectContent());
			column.addElement(headerTable);
			column.setSimpleColumn(30, 30, doc.getPageSize().getWidth(), top); // set LLx, LLy, URx, and URy of the header
			column.go();
		}
	}
	
	public void printFooter(Document doc, ByteArrayOutputStream baos)  throws DocumentException, IOException {
		try {
			Footer footer = getReportDefinition().getFooter();
			
			PdfPTable footerTable = null;
			if (footer != null && footer.getTable()!= null && footer.getTable().size() > 0) {
				/*File inputFile = new File(dr.getRootPath(getReportDefinition().getFileName()));
				byte[] b = new byte[(int) inputFile.length()];
				FileInputStream fileInputStream = new FileInputStream(inputFile);
				fileInputStream.read(b);*/
				
				PdfReader reader = new PdfReader(baos.toByteArray());
		        
				// Create a stamper
				PdfStamper stamper = new PdfStamper(reader, baos);
		        
				// Loop over the pages and add a header to each page
		        setTotalPageNo(reader.getNumberOfPages());
		        
		        for (int i = 1; i <= getTotalPageNo(); i++) {
		        	setPageNo(i);
		        	for (Table table : footer.getTable()) {
						footerTable = genPDFPTable(doc, footerTable, table);
					}
		        	footerTable.writeSelectedRows(0, -1, 34, 23, stamper.getOverContent(i));
		        }

		        // Close the stamper
		        stamper.close();
		        reader.close();
//		        fileInputStream.close();		        
			}
		} catch (Exception ex) {
			System.out.println(ex.toString());
		}
	}
			
	/**
	 * define the column string (display value & pattern) for the PDF file table column 
	 * @param xmlValue
	 * @param pattern
	 * @return String
	 */
	protected String defineColumnValue(String xmlValue, String pattern) {
		String returnVal = "";
		
		if ("#SYS_DATE".equalsIgnoreCase(xmlValue) || "#SYS_TIME".equalsIgnoreCase(xmlValue)) {
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			returnVal = format.format(new java.util.Date());
		} else if ("#PAGE".equalsIgnoreCase(xmlValue)) {
			returnVal = writer.getPageNumber()+"";
		} else {
			return xmlValue;
		}
		
		return returnVal;
	}
}