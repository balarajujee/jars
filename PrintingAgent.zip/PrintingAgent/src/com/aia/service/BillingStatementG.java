package com.aia.service;

import ho.aia.utility.host.PasswordFile;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import com.aia.common.db.DBCommon;
import com.aia.pdfGenerator.model.Reports;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericGenerator;
import com.ibm.as400.access.AS400;
import com.ibm.as400.access.IFSFile;
import com.ibm.as400.access.IFSFileInputStream;

/**
 * @author ITT0152
 *
 */

public class BillingStatementG extends Thread {

	/**
	 * @param args
	 */
	
	private Thread t;
	public BillingStatementG() {
		System.out.println("Creating thread BillingStatementG.." );
	}
	
	public void run(){
		
//		connectWindow();
		HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> ListOfBSFiles = getbillstatdetails();
	    HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> ListOfGSTFiles = getgstdetails();
		int noFiles;
		noFiles = ListOfBSFiles.size();
		System.out.println("noFiles : "+noFiles);
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
		
	//	Date datee = new Date();
	//	String date = sdfDate.format(datee);
	//	try{
			
		for (int i=0 ; i< noFiles ; i++){
			HashMap<Integer, HashMap<String, String>> billStatRS = ListOfBSFiles.get(i);
			HashMap<Integer, HashMap<String, String>> gstSummary = ListOfGSTFiles.get(i);
			ByteArrayOutputStream baos = genBillingStatement(billStatRS,gstSummary);
			String date = billStatRS.get(0).get("BillNum").substring(4,10);
			String groupNum = billStatRS.get(0).get("BillNum").substring(billStatRS.get(0).get("BillNum").length()-3);
			String billNum = billStatRS.get(0).get("BillNum").substring(11,billStatRS.get(0).get("BillNum").length()-4);
	//		System.out.println(" calling conn to SMB--------->: " + date);

			String path = "";
			ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
			path= bundle.getString("WritePathFile");
			
//			String pathFile = path+"//PET." + date+"_"+ billNum +"_" + "CoverLetter.pdf";	
			String pathFile =path+"PET." + date+"_"+ billNum +"_" +groupNum+"_"+"BillingStatement.pdf";	
			uploadLocalFile(baos,pathFile);
		}
		System.out.println("BillingStatementG thread Stopped....");

   }

   
   public static  HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> getbillstatdetails(){
	   HashMap<Integer, HashMap<String, String>> billStatRS = new HashMap<Integer, HashMap<String, String>>();
	   HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> Listtaxinvdetails = new HashMap<Integer ,HashMap<Integer, HashMap<String, String>>>();
       try {
    	  
    	//   String FILENAME = "D:\\TEST_Read\\Petronas_Billing_Stmt_20180601_0010.txt";
    	   
    	   /*BufferedReader br = null;
   		   FileReader fr = null;
    	   
            fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);*/
			
			System.out.println("Calling connAS400ReadFile Method");
			   BufferedReader br = connAS400ReadFile();
			   
			   if(br == null || br.equals("")){
				   System.out.println("No Billing Statment Flat file ");
			   }else{
			String sCurrentLine;
			int cuurline = 0,pdfgenCount = 0;
			int runline = 0;
			int IncVal = 0;
			HashMap<String, String> billstatdetails = new HashMap<String, String>();
			System.out.println("END connAS400ReadFile Method");
			while ((sCurrentLine = br.readLine()) != null) {
			//	System.out.println("sCurrentLine"+sCurrentLine);
			//	System.out.println("cuurline------->" + cuurline);
				if(cuurline >= 1){
					if(cuurline == 1){
						runline = 1;
					}
				
				 String[] data = sCurrentLine.split("\\|");
				 
				 for(int i=0; i<data.length; i++){
					 if(runline > 0){
				 if(runline == 1){
	     		 if(i == 2){
	     			billstatdetails.put("Name", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	     		 }else if(i == 3){
	     			billstatdetails.put("address1", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	      		 }else if(i == 4){
	      			billstatdetails.put("address2", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	     		 }else if(i == 5){
	     			billstatdetails.put("address3", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	      		 }else if(i == 6){
	     			billstatdetails.put("address4", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	      		 }else if(i == 7){
	     			billstatdetails.put("address5", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	      		 }else if(i == 8){
	      			billstatdetails.put("PersonName", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	       		 }else if(i == 9){
	       			billstatdetails.put("DateIssued", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
       			 }else if(i == 10){
       				billstatdetails.put("BillNum", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
       			 } 
			 }
			 if(runline == 2){ 
					 if(i == 2){
						 billstatdetails.put("TotalMnthFee", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
			     	 }else if(i == 3){
			     		billstatdetails.put("CurrRM", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
			      	 }
				 }
			 if(runline == 3){ 
				 if(i == 2){
					 billstatdetails.put("GoodsServiceTax", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }else if(i == 3){
		     		billstatdetails.put("GoodsTax", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		      	 }
			 }
			 if(runline == 4){ 
				 if(i == 2){
					 billstatdetails.put("ServiceTax", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }
				 else if(i == 3){
			     		billstatdetails.put("STax", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
				 }
			 }
			 if(runline == 5){ 
				 if(i == 2){
					 billstatdetails.put("AmountDue", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }	 
			 }
			 }
			}
				// billstatdetails.put("BillStatment","$%BillStat%$");
				 if (sCurrentLine.contains("****")){
					 System.out.println("Sys out 8");
					 billStatRS.put(IncVal, billstatdetails); 
					 IncVal++;
					Listtaxinvdetails.put(pdfgenCount, billStatRS);
					System.out.println("Sys out 9");
					billstatdetails = new HashMap<String, String>();
					billStatRS = new HashMap<Integer, HashMap<String, String>>(); 
					if (cuurline > 0)
						pdfgenCount++;
					    runline = 0;
					    IncVal=0;
				//	 System.out.println("Listtaxinvdetails--> " + Listtaxinvdetails);
						}
				 else if(!sCurrentLine.contains("****") && runline >= 2){
					 billStatRS.put(IncVal, billstatdetails); 
					 IncVal++;
					Listtaxinvdetails.put(pdfgenCount, billStatRS);
				 }
				}
				 runline++;
			//}
				cuurline++;	
			} 
			   }
	          } catch(Exception ex) {
	                 System.out.println("[BillingStatementG.getbillstatdetails] Exception: " + ex.toString());
	                 ex.printStackTrace();
	          }
	       System.out.println("getbillstatdetails() :"+Listtaxinvdetails);
	       return Listtaxinvdetails;  
	   }
  
   
   public static HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> getgstdetails(){
	   HashMap<Integer, HashMap<String, String>> gstSummary = new HashMap<Integer, HashMap<String, String>>();
	   HashMap <Integer ,HashMap<Integer, HashMap<String, String>>> Listgstdetails = new HashMap<Integer ,HashMap<Integer, HashMap<String, String>>>();
       try {
    	  
    	  
    	   String FILENAME = "D:\\TEST_Read\\Petronas_Billing_Stmt_20180601_0010.txt";
    	   
    	   BufferedReader br = null;
   		   FileReader fr = null;
    	   
            fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
				
				System.out.println("Calling connAS400ReadFile Method");
				//   BufferedReader br = connAS400ReadFile();
				   
				   if(br == null || br.equals("")){
					   System.out.println("No Billing Statment Flat file ");
				   }else{
		    	   
				//   System.out.println("END connAS400ReadFile Method");
			
			String sCurrentLine;
			int cuurline = -1, pdfgencount = 0;
			
			
			
			while ((sCurrentLine = br.readLine()) != null) {
			//	System.out.println("getgstdetails() : sCurrentLine"+sCurrentLine);
				 Boolean add = false;
				 
				HashMap<String, String> gstdetails = new HashMap<String, String>();
				
				if(cuurline == -1 || sCurrentLine.contains("****")){
					gstdetails = new HashMap<String, String>();
					gstSummary = new HashMap<Integer, HashMap<String, String>>(); 
					if(sCurrentLine.contains("****")){
						pdfgencount++;
					}
					cuurline=-1;
				}
				
				 String[] data = sCurrentLine.split("\\|");
				 
				 for(int i=0; i<data.length; i++){  
						
					 if(data[0].equalsIgnoreCase("0003")){
						 add = true;
					 }
					 
				if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("1T") && i == 2){
					gstdetails.put("TaxRate", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
				 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 2){
				    gstdetails.put("SeqNo", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
				 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 3){
	     			gstdetails.put("TaxCode", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
	     		 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 4){
	     			gstdetails.put("TransDate", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 5){
		     		gstdetails.put("ProdDesc", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 6){
		     		gstdetails.put("AmtExclGST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 7){
		     		gstdetails.put("AmtGST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 8){
			     	gstdetails.put("AmtST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");	
		     	 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("2T") && i == 9){
		     		gstdetails.put("AmtInclGST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
		     	 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("3T") && i == 2){
				    gstdetails.put("totalExcGST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
			     }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("3T") && i == 3){
			     	gstdetails.put("totalGST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
			     }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("3T") && i == 4){
				    gstdetails.put("totalST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
				 }else if(data[0].equalsIgnoreCase("0003") && data[1].equalsIgnoreCase("3T") && i == 5){
			        gstdetails.put("totalIncGST", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
			      }
			 }
				 gstdetails.put("BillStatment","$%BillStat%$"); 
				 if(add){
					 cuurline++;
					 gstSummary.put(cuurline, gstdetails);
			//		 System.out.println("pdfgencount------> " + pdfgencount);
					 Listgstdetails.put(pdfgencount, gstSummary); 
		//           System.out.println("cuurline------> " + cuurline);
				  //   System.out.println("Listgstdetails inside------> " + Listgstdetails);
				 }
			  }
			} 
	          } catch(Exception ex) {
	                 System.out.println("[BillingStatementG.getgstdetails] Exception: " + ex.toString());
	                 ex.printStackTrace();
	          }
      // System.out.println("Listgstdetails: "+Listgstdetails);
	       return Listgstdetails;  
	   }
	
   
   public static synchronized void uploadLocalFile(ByteArrayOutputStream baos, String pathFile){ 
      
	   System.out.println(" calling conn to SMB:");
		SmbFileOutputStream sfos = null;
      try {
	/*		ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
			PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONASWIN", "USER", "PASSWD");
  	   NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", pwdFile.getUserId(), pwdFile.getPassword());
//   	   NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", "KAPPUSON", "Welcome@1");
   	      //  System.out.println("File Path :"+pathFile);
   	        System.out.println("Auth connect done");
   	        SmbFile smbfile = new SmbFile(pathFile, auth);
   	        System.out.println("smbfile...:"+smbfile);
   	     //   String pathnew =  pathFile +"//PET." + "CoverLetter.pdf";
   	        sfos = new SmbFileOutputStream(smbfile);
                
                 baos.writeTo(sfos);
                 sfos.close();
       System.out.println(" Uploaded to PFV: " + pathFile);
       reNameFile();*/
    	  
    	  FileOutputStream fos = new FileOutputStream (new File(pathFile));
   	      baos.writeTo(fos);
          fos.close();
    	  
    	  
      } catch(Exception ex){
             System.out.println("[BillingStatementG.uploadLocalFile] Exception: " + ex.toString());
             ex.printStackTrace();
      }
    }
     
   public static ByteArrayOutputStream genBillingStatement(HashMap<Integer, HashMap<String, String>> billStatRS, HashMap<Integer, HashMap<String, String>> gstSummary){
		GenericGenerator pdfGenerator = new GenericGenerator();
		CommonFileUtil cu = new CommonFileUtil();
		DBCommon dc = new DBCommon();
		
		ByteArrayOutputStream crBaos = new ByteArrayOutputStream();
       
		try {
			
			//String path = "D:\\TEST_Read\\BillingStatement.xml";
			String path = "";
			ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
			path= bundle.getString("FileXmlPath");
			path = path+"BillingStatement.xml";	
			System.out.println("path:"+path);
			
			
			// Read XML to Java object
	    	JAXBContext jc = JAXBContext.newInstance("com.aia.pdfGenerator.model");
	
	        Unmarshaller um = jc.createUnmarshaller();
	        Reports rpt = (Reports) um.unmarshal(new File(path));
			
           pdfGenerator.setReportDefinition(rpt);
           
           pdfGenerator.setDbData(billStatRS);
           pdfGenerator.setGstSummary(gstSummary);
           pdfGenerator.setCurrRowDBData(null);
           
           crBaos = pdfGenerator.runReport();
           
           return crBaos;
       } catch (JAXBException jex) {
       	System.out.println("[BillingStatementG.java] [genBillingStatement] JAXBException --> " + jex.toString());
       } catch (Exception ex) {
       	ex.printStackTrace();
       }
		return null;
   }
     
	
	  public static  BufferedReader connAS400ReadFile(){
		  System.out.println(" In connAS400ReadFile");
		  String processFile = "";
		  String totPath = "";
		  String ipAdd = "";
		  String folPath ="";
		  SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
		  Date datee = new Date();
		  String date = sdfDate.format(datee);
		  IFSFileInputStream inputStream = null;
//		  IFSFileInputStream inputStream_ = new IFSFileInputStream(file);
		  BufferedReader reader = null;
			   FileReader fr = null;
				try {
					ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
					PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONAS", "USER", "PASSWD");
					totPath = bundle.getString("FileReadPath");
					ipAdd = totPath.substring(0, totPath.indexOf("/"));
					folPath = totPath.substring(totPath.indexOf("/"));
					System.out.println("IP :"+ipAdd +", Path:"+folPath);
					/*System.out.println("UserID:"+bundle.getString("UserID"));
					System.out.println("Password:"+bundle.getString("Password"));
					System.out.println("DATE:---->"+  date);*/
					AS400 as400 = new AS400(ipAdd, "G4UKD", "ABCD1234");
		              IFSFile path = new IFSFile(as400, folPath);
		              if (path.isDirectory()) {
		                     IFSFile[] files = path.listFiles();
		                     
		                     System.out.println("passed");
		                     
		                     for (IFSFile file : files) {
		//                           System.out.println("insideee" + file.getName().contains("Billing_Stmt"));
		                           if(file.isFile() && file.getName().contains("Adhoc_Petronas_Billing_Stmt") && file.getName().contains(date) && file.getName().endsWith(".txt")){
		                        	   inputStream = new IFSFileInputStream(file);
		                        	    reader = new BufferedReader(new InputStreamReader(inputStream));
		                        	   /* IFSFile file1 = new IFSFile(as400, folPath+"/"+file.getName()+".bak");
		                        	    System.out.println("File1 Path :"+file1.getParent());
		                        	    System.out.println("File1 Name :"+file1.getName());
		                        	    file.renameTo(file1);
		                        	    System.out.println("File Name after Rename:"+file.getName()); */
		                           }
		                     }
		              }

					
				}catch(Exception e){
					System.out.println("[BillingStatementG][connAS400ReadFile] Exception -- " + e.toString());
				}
				
				return reader;
			}
	  
	  public void startBatch() {
			System.out.println("Starting thread ");
			
			if (t == null) {
				t = new Thread(this);
				t.start();
			}
		}
	  

	  public static void reNameFile(){

		  System.out.println(" In connAS400ReadFile");
		  String processFile = "";
		  String totPath = "";
		  String ipAdd = "";
		  String folPath ="";
		  SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMM");
		  Date datee = new Date();
		  String date = sdfDate.format(datee);
				try {
					ResourceBundle bundle=PropertyResourceBundle.getBundle("dbConnect");
					PasswordFile pwdFile = new PasswordFile (bundle.getString("DatabasePasswordFileDirectory"), "PETRONAS", "USER", "PASSWD");
					totPath = bundle.getString("FileReadPath");
					ipAdd = totPath.substring(0, totPath.indexOf("/"));
					folPath = totPath.substring(totPath.indexOf("/"));
					System.out.println("IP :"+ipAdd +", Path:"+folPath);
					/*System.out.println("UserID:"+bundle.getString("UserID"));
					System.out.println("Password:"+bundle.getString("Password"));
					System.out.println("DATE:---->"+  date);*/
					AS400 as400 = new AS400(ipAdd, "G4UKD", "ABCD1234");
		              IFSFile path = new IFSFile(as400, folPath);
		              if (path.isDirectory()) {
		                     IFSFile[] files = path.listFiles();
		                     
		                     for (IFSFile file : files) {
		//                           System.out.println("insideee" + file.getName().contains("Billing_Stmt"));
		                           if(file.isFile() && file.getName().contains("Adhoc_Petronas_Billing_Stmt") && file.getName().contains(date) && file.getName().endsWith(".txt")){
		                        	    IFSFile file1 = new IFSFile(as400, folPath+"/"+file.getName()+".bak");
		                        	    System.out.println("File1 Path :"+file1.getParent());
		                        	    System.out.println("File1 Name :"+file1.getName());
		                        	    file.renameTo(file1);
		                        	    System.out.println("File Name after Rename:"+file.getName()); 
		                           }
		                     }
		              }

					
				}catch(Exception e){
					System.out.println("[BillingStatementG][connAS400ReadFile] Exception -- " + e.toString());
				}
	  }
	  
	public void connectWindow(){

		 String writeFolder = "smb://10.49.197.43/UAT/PETRONAS/OUT/MONTHLY_BILLING/";
			try {	
				NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("AIA", "KAPPUSON", "Welcome@1");
				System.out.println(" Auth inside Billing Statment");
              SmbFile depDir = new SmbFile(writeFolder, auth);
              for (SmbFile f : depDir.listFiles())
              {
                //  System.out.println(f.getName());
              }
			}catch(Exception e){
				System.out.println("[BillingStatementG][connAS400ReadFile] Exception -- " + e.toString());
			}
	}
	
	public static void main(String args[]){
		BillingStatementG bs = new BillingStatementG();
		bs.run();
	}
   
}