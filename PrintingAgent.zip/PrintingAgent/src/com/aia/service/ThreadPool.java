package com.aia.service;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ThreadPool {
	int poolSize = 3;
	int maxPoolSize = 10;
    long keepAliveTime = 900;
    private ThreadPoolExecutor threadPool = null;

	final ArrayBlockingQueue<Runnable> queue = new ArrayBlockingQueue<Runnable>(10);
    
    public ThreadPool() {
        threadPool = new ThreadPoolExecutor(poolSize, maxPoolSize, keepAliveTime, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>()); 
    }
    
    public void runTask(Runnable task) {
        threadPool.execute(task);                
    }
 
    public void shutDown() {
        threadPool.shutdown();
    }
    
    public boolean isTerminated() {
    	return threadPool.isTerminated();
    }
    
    public boolean isShutDown() {
    	return threadPool.isShutdown();
    }
    
    public ThreadPoolExecutor getThreadPool() {
		return threadPool;
	}
}