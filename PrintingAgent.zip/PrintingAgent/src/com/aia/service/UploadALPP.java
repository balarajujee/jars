package com.aia.service;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.UUID;

import com.aia.common.db.DBCommon;
import com.aia.common.model.AgentContract;
import com.aia.common.model.AppForm;
import com.aia.common.model.PolCoverage;
import com.aia.common.model.PolicyInfo;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.ESBUtil;
import com.aia.pdfGenerator.util.GenericUtil;
import com.aia.utility.CommonUtil;

public class UploadALPP {
	public void upload(ByteArrayOutputStream fullPdfBaos, String companyCode, String policyNo, String icNo, 
			Date receivedDate) {
		DBCommon dc = new DBCommon();
		
		try {
			System.out.println("Uploading to Imaging DB for ALPP...");
			
			Date now = new Date();
			SimpleDateFormat sdfMonth = new SimpleDateFormat("MM");
			SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy");
			
			String processMonth = sdfMonth.format(now);
			String processYear = sdfYear.format(now);
			
			String tableDocName = "tbl_epc_" + processMonth + "_" + processYear;
			dc.validateTableByMonthYear(tableDocName);
			
			String docId = UUID.randomUUID().toString().toUpperCase();
			
			if(fullPdfBaos != null && fullPdfBaos.toByteArray().length > 0) {
				dc.addALPPDocImage(docId, fullPdfBaos, tableDocName);
				
			} else {
				System.out.println("Error: Full contract PDF is null...");
			}
			
			String baseId = UUID.randomUUID().toString().toUpperCase();
			SimpleDateFormat dbDate = new SimpleDateFormat("yyyy-MM-dd");
			
			tableDocName = "[" + tableDocName + "]";
			dc.addALPPDocBase(baseId, docId, "EPC01", policyNo, icNo, processYear, tableDocName, dbDate.format(receivedDate));
			
			System.out.println("PDF uploaded to Imaging DB for ALPP.");
			
		} catch(Exception ex) {
			System.out.println("[UploadALPP.upload] Exception: " + ex.toString());
			ex.printStackTrace();
		} 
	}

	public void sendEmail(ByteArrayOutputStream fullPdfBaos, String companyCode, PolicyInfo policyInfo, AppForm appForm, 
			String templateCode) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GeneratePDF gp = new GeneratePDF();
		
		try {
			if(cu.isBlank(policyInfo.getInsuredEmail())) {
				System.out.println("Email is null. Not sending email to customer " +
						"for policy " + policyInfo.getPolicyNo() + "...");
			} else {
				System.out.println("Sending email to customer for policy " + policyInfo.getPolicyNo() + "...");
				
				String subject = "Confirmation for " + appForm.getPlanName();
				if("MS".equals(appForm.getPolLanguage())) {
					subject = "Pengesahan untuk " + appForm.getPlanName();
				}
				
				String promoCode = getPromoCode(templateCode);
				
				if("TPL003".equalsIgnoreCase(templateCode)) {
					String preRegKey = "";
					String trxno = "";
					Date dNow = new Date( );
					SimpleDateFormat ft =  new SimpleDateFormat ("ddMMyyyyhhmmss");
					UUID uuid = UUID.randomUUID();
					System.out.println("Rest Webservice API Test : "+"eCom"+ft.format(dNow)+uuid.toString().substring(0, 7));
					trxno = "eCom"+ft.format(dNow)+uuid.toString().substring(0, 7);

					boolean isPreReg = ESBUtil.isRegistered(policyInfo, appForm,trxno);
					if(!isPreReg){
					    preRegKey =  ESBUtil.createPreRegKey(policyInfo, appForm ,trxno);
						if(preRegKey.contains("Err From ESB")){
							preRegKey = "";
						}
						System.out.println("preRegKey for ..."+policyInfo.getPolicyNo()+" :: "+preRegKey);
						String content = processCiCareContentNew(companyCode, policyInfo, appForm, promoCode, templateCode,preRegKey);
					    dc.setALPPEmail(policyInfo.getInsuredEmail(), subject, content , "","");
					  //dc.setALPPEmail("ChinLong.Tok@aia.com", subject, content, "","");
					}else{
						String content = processCiCareContentExist(companyCode, policyInfo, appForm, promoCode, templateCode,preRegKey);
						dc.setALPPEmail(policyInfo.getInsuredEmail(), subject, content , "","");
//						dc.setALPPEmail("ChinLong.Tok@aia.com", subject, content, "","");
					}
				} else {
					String content = processContent(companyCode, policyInfo, appForm, promoCode, templateCode);
					if("072".equals(companyCode)) content = processTkfContent(companyCode, policyInfo, appForm, promoCode, templateCode);
					dc.setALPPEmail(policyInfo.getInsuredEmail(), subject, content , "","");
//					dc.setALPPEmail("ChinLong.Tok@aia.com", subject, content, "","");
				}
				
				int masterId = dc.getLatestIdForEmail(policyInfo.getInsuredEmail());
				fullPdfBaos = gp.encryptPDF(fullPdfBaos, policyInfo.getInsuredMykad());
				dc.setALPPEmailAttachment(masterId, fullPdfBaos, policyInfo.getPolicyNo());
				
				// set promo code to being used once email set
				if(!cu.isBlank(promoCode)) dc.updatePromoCode(promoCode, templateCode);
				
				System.out.println("Email sent to customer for policy " + policyInfo.getPolicyNo() + ".");
			}
		} catch(Exception ex) {
			System.out.println("[UploadALPP.sendEmail] Exception: " + ex.toString());
			ex.printStackTrace();
		} 
	}

	public void sendEmailAgent(Map<String, ByteArrayOutputStream> pdfBaosMap, String companyCode,AgentContract agentContract,String templateCode) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GeneratePDF gp = new GeneratePDF();
		String subject = "";
		String emailBody = "";
		try {
			if(cu.isBlank(agentContract.getEmailTo())) {
				System.out.println("Email is null. Not sending email to Agent/Agent Manager " +
						"for Id Number " + agentContract.getIdNo() + "...");
			} else {
				System.out.println("Sending email to customer for Id Number " + agentContract.getIdNo() + "...");
				ResourceBundle bundle = PropertyResourceBundle.getBundle("emailTemplate");
				if("APPLICATION".equalsIgnoreCase(agentContract.getContractType())){
					if("AGENT".equalsIgnoreCase(agentContract.getAgentRank())){
						if("Life Planner".equalsIgnoreCase(agentContract.getProgramType()) || "ELITE II".equalsIgnoreCase( agentContract.getProgramType()) || "ELITE III".equalsIgnoreCase( agentContract.getProgramType()) || "ELITE I".equalsIgnoreCase( agentContract.getProgramType())){
							// get temp1
							emailBody = bundle.getString("temp1");
							emailBody = emailBody.replace("$%ApplicantName%$", agentContract.getAgentName());
							emailBody = emailBody.replace("$%AgentCode%$", agentContract.getAgentCode());
							SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
							String conDate = sdf.format(agentContract.getContractDate());
							emailBody = emailBody.replace("$%EffectiveDate%$", conDate);
							emailBody = emailBody.replace("$%AIAAgentEmail%$", agentContract.getAgentEmail());
							
							 subject = bundle.getString("applicationsub");
						}/*else if("SU36".equalsIgnoreCase( agentContract.getProgramType())){
							// get temp2
							emailBody = bundle.getString("temp2");
							emailBody = emailBody.replace("$%ApplicantName%$", agentContract.getAgentName());
							emailBody = emailBody.replace("$%AgentCode%$", agentContract.getAgentCode());
							emailBody = emailBody.replace("$%STSCode%$", agentContract.getStsCode());
							SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
							String conDate = sdf.format(agentContract.getContractDate());
							emailBody = emailBody.replace("$%EffectiveDate%$", conDate);
							emailBody = emailBody.replace("$%AIAAgentEmail%$", agentContract.getAgentEmail());
							
							 subject = bundle.getString("applicationsub");
						}*/
						
					}else if("UNIT MANAGER".equalsIgnoreCase(agentContract.getAgentRank()) || "DISTRICT MANAGER".equalsIgnoreCase(agentContract.getAgentRank())){
						//get temp3
						emailBody = bundle.getString("temp3");
						emailBody = emailBody.replace("$%ApplicantName%$", agentContract.getAgentName());
						emailBody = emailBody.replace("$%AgentCode%$", agentContract.getAgentCode());
						emailBody = emailBody.replace("$%AgencyCode%$", agentContract.getAgencyCode());
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
						String conDate = sdf.format(agentContract.getContractDate());
						emailBody = emailBody.replace("$%EffectiveDate%$", conDate);
						emailBody = emailBody.replace("$%AIAAgentEmail%$", agentContract.getAgentEmail());
						
						 subject = bundle.getString("applicationsub");
					}
					
				}else if("PROMOTION".equalsIgnoreCase(agentContract.getContractType())){
					emailBody = bundle.getString("temp4");
					emailBody = emailBody.replace("$%ApplicantName%$", agentContract.getAgentName());
					emailBody = emailBody.replace("$%Promotion_Type%$", agentContract.getAgentRank());
					emailBody = emailBody.replace("$%New_AgencyCode%$", agentContract.getAgencyCode());
					SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
					String conDate = sdf.format(agentContract.getContractDate());
					emailBody = emailBody.replace("$%EffectiveDate%$", conDate);
					
					 subject = bundle.getString("promosub");
					 subject = subject.replace("$%Rank of Promotion Apply%$", agentContract.getAgentRank());
					 subject = subject.replace("$%ApplicantName%$", agentContract.getAgentName());
				}
				System.out.println("Sending email to subject is " + subject);
				
//				String promoCode = getPromoCode(templateCode);
			//	 int masterId =  dc.setALPPEmail(agentContract.getEmailTo(), subject, emailBody ,agentContract.getEmailCc()+",Kishorekumar.yaddala@aia.com,SazarulIzam.MdSaad@aia.com","MY.BeALifePlanner@aia.com");
				 int masterId =  dc.setALPPEmail(agentContract.getEmailTo(), subject, emailBody ,agentContract.getEmailCc(),"MY.BeALifePlanner@aia.com");
				//  int masterId =  dc.setALPPEmail("Kishorekumar.yaddala@aia.com", subject, emailBody, "SazarulIzam.MdSaad@aia.com","MY.BeALifePlanner@aia.com");
				// int masterId =  dc.setALPPEmail("Kishorekumar.yaddala@aia.com", subject, emailBody, "","MY.BeALifePlanner@aia.com");
				System.out.println("Master Id for - "+ agentContract.getContractId() + " - is - "+masterId);
				
				//int masterId = dc.getLatestIdForEmail("SazarulIzam.MdSaad@aia.com");
				//int masterId = dc.getLatestIdForEmail(agentContract.getEmailTo());
				//fullPdfBaos = gp.encryptPDF(fullPdfBaos, agentContract.getIdNo());
				 if(!cu.isBlank(pdfBaosMap)) {
						Iterator<Map.Entry<String, ByteArrayOutputStream>> it = pdfBaosMap.entrySet().iterator();
						
						while(it.hasNext()) {
							Map.Entry<String, ByteArrayOutputStream> pair = (Map.Entry<String, ByteArrayOutputStream>) it.next();
							String templCode = pair.getKey();
							String attName = "";
							if("S00006".equalsIgnoreCase(templCode) ){
								attName = " - AGENTCON";
							}else if("S00009".equalsIgnoreCase(templCode)){
								attName = " - AGENTTKF";
							}else if("S00007".equalsIgnoreCase(templCode)){
								attName = " - UNIT MANAGERCON";
							}else if("S00010".equalsIgnoreCase(templCode)){
								attName = " - UNIT MANAGERTKF";
							}else if("S00008".equalsIgnoreCase(templCode)){
								attName = " - DIST MANAGERCON";
							}else if("S00011".equalsIgnoreCase(templCode)){
								attName = " - DIST MANAGERTKF";
							}
							ByteArrayOutputStream pdfBaos = pair.getValue();
							pdfBaos = gp.encryptPDF(pdfBaos, agentContract.getIdNo());
							dc.setALPPEmailAttachment(masterId, pdfBaos, agentContract.getAgentCode()+attName);
						}
					}
				 
			//	dc.setALPPEmailAttachment(masterId, fullPdfBaos, agentContract.getAgentCode()+" - AGENT");
				
			
				System.out.println("Email sent to customer for policy " +agentContract.getIdNo() + ".");
			}
		} catch(Exception ex) {
			System.out.println("[UploadALPP.sendEmail] Exception: " + ex.toString());
			ex.printStackTrace();
			
		} 
	}

	private String processCiCareContentNew(String companyCode, PolicyInfo policyInfo, AppForm appForm, String promoCode, 
			String templateCode , String preRegKey) {
		String content = "";
		String benefitAmount = "";
		try {
			ResourceBundle bundle = PropertyResourceBundle.getBundle("emailTemplate");
			content = bundle.getString("cicareTemp1");
			content +=  bundle.getString("cicareTemp2");
			content +=  bundle.getString("cicareTemp3");
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Now use today date.
			c.add(Calendar.DATE, 90); // Adding 90 days
			String expDate = sdf.format(c.getTime());
			System.out.println("[UploadALPP][processContentNew]expDate.."+expDate);
			System.out.println("[UploadALPP][processContentNew] PreRegKey:"+preRegKey);
			content = content.replace("$%ownerName%$",policyInfo.getOwnerName()) ;
			content = content.replace("$%telNo%$",appForm.getTelNo());
			content = content.replace("$%planName%$",appForm.getPlanName());
			content = content.replace("$%policyNo%$",policyInfo.getPolicyNo());
			content = content.replace("$%totalAmount%$",policyInfo.getTotalAmount().toString());
			content = content.replace("$%polDate%$",GenericUtil.dateToStr(policyInfo.getPolicyDate(), "MMM dd, yyyy"));
			content = content.replace("$%issueDate%$",GenericUtil.dateToStr(policyInfo.getIssueDate(), "MMM dd, yyyy"));
			content = content.replace("$%polExpDate%$",GenericUtil.dateToStr(policyInfo.getMaturityDateCICare(), "MMM dd, yyyy"));
			for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
				PolCoverage cov = policyInfo.getCoverages().get(i);
				benefitAmount = CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0).toString();
			}
			content = content.replace("$%benifitAmt%$",benefitAmount);
			content = content.replace("$%linkExpDate%$",expDate);
			content = content.replace("$%myAIALogOn%$",bundle.getString("myAIALogOn"));
			content = content.replace("$%preregistrationlink%$",bundle.getString("preregistrationlink")+preRegKey);
			content = content.replace("$%claimURL%$",bundle.getString("claimURL"));
			content = content.replace("$%AIAHelpURL%$",bundle.getString("AIAHelpURL"));
		} catch(Exception ex) {
			System.out.println("[UploadALPP.processContent] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		
		
		return content;
	}	

	private String processCiCareContentExist(String companyCode, PolicyInfo policyInfo, AppForm appForm, String promoCode, 
			String templateCode , String preRegKey) {
		String content = "";
		String benefitAmount = "";
		try {
			ResourceBundle bundle = PropertyResourceBundle.getBundle("emailTemplate");
			content = bundle.getString("cicareExistTemp");
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Now use today date.
			c.add(Calendar.DATE, 90); // Adding 90 days
			String expDate = sdf.format(c.getTime());
			System.out.println("[UploadALPP][processContentNew]expDate.."+expDate);
			
			content = content.replace("$%ownerName%$",policyInfo.getOwnerName()) ;
			content = content.replace("$%telNo%$",appForm.getTelNo());
			content = content.replace("$%planName%$",appForm.getPlanName());
			content = content.replace("$%policyNo%$",policyInfo.getPolicyNo());
			content = content.replace("$%totalAmount%$",policyInfo.getTotalAmount().toString());
			content = content.replace("$%polDate%$",GenericUtil.dateToStr(policyInfo.getPolicyDate(), "MMM dd, yyyy"));
			content = content.replace("$%issueDate%$",GenericUtil.dateToStr(policyInfo.getIssueDate(), "MMM dd, yyyy"));
			content = content.replace("$%polExpDate%$",GenericUtil.dateToStr(policyInfo.getMaturityDateCICare(), "MMM dd, yyyy"));
			
			for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
				PolCoverage cov = policyInfo.getCoverages().get(i);
				benefitAmount = CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0).toString();
			}
			
			content = content.replace("$%benifitAmt%$",benefitAmount);
			content = content.replace("$%myAIALogOn%$",bundle.getString("myAIALogOn"));
			content = content.replace("$%claimURL%$",bundle.getString("claimURL"));
			content = content.replace("$%AIAHelpURL%$",bundle.getString("AIAHelpURL"));
			
		} catch(Exception ex) {
			System.out.println("[UploadALPP.processContent] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return content;
	}
	
	/*private String processContentNew(String companyCode, PolicyInfo policyInfo, AppForm appForm, String promoCode, 
			String templateCode , String preRegKey) {
		String content = "";
		//String preregistrationlink = "https://www.aia.com.my/en/my-aia/registration.html?type=2&PreRegAuthKey="+preRegKey;
		String preregistrationlink = "https://wwwuat2.aia.com.my/en/my-aia/registration.html?type=2&PreRegAuthKey="+preRegKey;
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Now use today date.
			c.add(Calendar.DATE, 90); // Adding 90 days
			String expDate = sdf.format(c.getTime());
			System.out.println("[UploadALPP][processContentNew]expDate.."+expDate);
			
			
			content += "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title></title>" +
					"<style>table { font-family: verdana, sans-serif; border-collapse: collapse; " +
					"width: 90%; font-size: 11px; } th { border: 1px solid gray; text-align: left; padding: 8px; " +
					"background-color: #dddddd; } td { border: 1px solid gray; text-align: left; " +
					"padding: 8px; } </style></head><body>";
			content += "<font face=\"verdana\" size=\"2\">";
			
			content += "Dear " + policyInfo.getOwnerName() + ",<br/><br/>";
			
			content += "We are pleased to enclose your policy document for your viewing. Your policy document will also " +
					"be available on <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> within 24 " +
					"hours after you have purchased your policy.<br/><br/>";
			
			content += "For confidentiality, the PDF attachment is password protected. " +
					"To view it, key in your password, which is your identification number (NRIC, passport, police or " +
					"army identification, whichever you provided). The password is case sensitive and requires no " +
					"hyphen or space.<br/><br/>";
			
			content += "Example ? 123456123456 or A12341234<br/><br/>";
			
			content += "Below is a summary of your purchase details: <br/><br/>";
			
			content += "<strong>Person Covered:</strong> "+ policyInfo.getOwnerName() +"<br/>";
			//content += "<strong>NRIC:</strong> "+ policyInfo.getOwnerMykad() +"<br/>";
			content += "<strong>Mobile Number:</strong> "+ appForm.getTelNo() +"<br/>";
			content += "<strong>Product:</strong> "+ appForm.getPlanName() +"<br/>";
			content += "<strong>Policy Number:</strong> "+ policyInfo.getPolicyNo() +"<br/>";
			content += "<strong>Total Premium:</strong> RM "+ policyInfo.getTotalAmount() +"<br/>";
			content += "<strong>Policy Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getPolicyDate(), 
					"MMM dd, yyyy") +"<br/>";
			content += "<strong>Issuance Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getIssueDate(), 
					"MMM dd, yyyy") +"<br/>";
			content += "<strong>Maturity or Expiry Date:</strong> "+ 
					GenericUtil.dateToStr(policyInfo.getExpiryDate(), "MMM dd, yyyy") +"<br/>";
			content += "<strong>Coverage Duration:</strong> 1 Year Only<br/><br/>";
			content += "<strong>What are your benefits under this plan?</strong><br/><br/>";
			
			content += "<center><table><tr><th>Benefits</th><th>Basic Coverage Amount</th></tr>";
			
			for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
				PolCoverage cov = policyInfo.getCoverages().get(i);
//				if(i == 0) {
					content += "<tr><td>CI Care Plus</td>" +
							"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
				} else if(i == 1) {
					content += "<tr><td>Total and Permanent Disability Benefit</td>" +
							"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
				}
			}
			
			content += "</table></center><br/><br/>";
			
			content += "For your reference, your e-Policy is available at the MY AIA portal <a href=\"" +
					"" +preregistrationlink+
					"\">" +
					"my aia pre-registration link</a> ." +
					"Please download to acknowledge receipt and read through.<br/><br/>";
			
			content += "<b><u>Begin your MY AIA journey today</u></b><br/><br/>";
			
			
			content += "<b>Step 1:</b> Click <a href=\"" +
					"" +preregistrationlink+
					"\">HERE</a> to activate your User ID by using your NRIC no. / passport no. " +
					"We have assigned you a pre-set User ID to enable you to login to the MY AIA portal. " +
					"Example: ****44848 (Your NRIC no. / passport no.)" +
					"Please enter your actual ID no. in full for MY AIA User ID activation process.</i><br/><br/>";
			
			content += "<b>Step 2:</b> Create your password </i><br/><br/> " ;
			content += "<b>Step 3:</b> Login to MY AIA portal to get information on your policy </i><br/><br/> " ;
			content += "Please activate your User ID within 90 days upon receipt of this email. " +
					" The activation link will be expired on " + expDate + " .<br/><br/>";
			
			
			content += "With access to MY AIA, you have added convenience and can download your policy, update your " +
					" contact details, update your credit card details and do so much more. Login today!<br/><br/>";
			
			
			content += "If you require any assistance, or have any questions about your policy, please reach out to our CareLine at 1800 38 3464. " +
					" You can also send us a message via the Contact Us section at MY AIA (https://www.aia.com.my/). <br/><br/>";
			
			String flpDays = ("TPL003".equalsIgnoreCase(templateCode))? "thirty (30)": "fifteen (15)";
			content += "<b><u>Important Notes</u></b><br/><br/>";
			content += "<b>Free Look Period</b> ? You may cancel your policy by writing in to us and returning " +
					"your policy contract within " + flpDays + " days after you have received your policy contract. The " +
					"premiums that you have paid will be refunded, after deducting any medical expenses you may " +
					"have incurred.<br/><br/>";
			content += "Once you receive your policy contract, please ensure that all the information in the contract is " +
					"complete and accurate. If you do not notify us of any inaccuracies, we will take the information that " +
					"was declared and submitted by you and/or your authorised representative as true, accurate and " +
					"complete.<br/><br/>";
			
			content += "The coverage amount and benefits of this Policy are detailed in the Schedule of Coverage, " +
					"Benefits and Premiums on the Policy Information Page. All benefits, benefit exclusions, conditions " +
					"for payment and other policy details are set out inside.<br/><br/>";
			
			content += "If you need to make a claim, please click " +
					"<a href=\"http://www.aia.com.my/en/help-support/claim-guide.html\">here</a> to find out " +
					"how to do so.<br/></br/>";
			
			content += "It is also advisable to nominate a nominee and ensure that the nominee is aware of the life " +
					"insurance policy that you have purchased. Without a nomination, policy moneys may be paid to the " +
					"lawful executor or administrator of your estate, subject to the Financial Services Act 2013. Click " +
					"<a href=\"https://www.aia.com.my/en/help-support.html?auto=30&q=nomi\">here</a> to find out " +
					"how.<br/><br/>";
			
			String aiaPhone = ("TPL003".equalsIgnoreCase(templateCode))? "1800 38 3464": "1300 88 1899";
			
			content += "If you have any questions, please Contact Us at: <br/>";
			content += "AIA Bhd - " + aiaPhone + "<br/>";
			
			content += "<br/>";
			
			content += "Our operating hours are:<br/>";
			content += "Monday to Thursday 8.30am - 5.30pm<br/>";
			content += "Friday 8.30am - 4.30pm<br/><br/>";
			
			content += "Thank you and enjoy your experience with My AIA.<br/><br/><br/>";
			
			content += "</font></body></html>";
			
		} catch(Exception ex) {
			System.out.println("[UploadALPP.processContent] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return content;
	}*/
	
	private String processContent(String companyCode, PolicyInfo policyInfo, AppForm appForm, String promoCode, 
			String templateCode) {
		String content = "";
		CommonFileUtil cu = new CommonFileUtil();
		
		try {
			if("MS".equalsIgnoreCase(appForm.getPolLanguage())) {
				content += "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title></title>" +
						"<style>table { font-family: verdana, sans-serif; border-collapse: collapse; " +
						"width: 90%; font-size: 11px; } th { border: 1px solid gray; text-align: left; padding: 8px; " +
						"background-color: #dddddd; } td { border: 1px solid gray; text-align: left; " +
						"padding: 8px; } </style></head><body>";
				content += "<font face=\"verdana\" size=\"2\">";
				
				content += "Kepada " + policyInfo.getOwnerName() + ",<br/><br/>";
				
				content += "Kami dengan sukacitanya melampirkan dokumen polisi  anda untuk tatapan anda. Dokumen anda " +
						"juga boleh didapati di <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> " +
						"dalam masa 24 jam selepas anda membeli polisi anda.<br/><br/>";
				
				if("TPL003".equalsIgnoreCase(templateCode) || "TPL006".equalsIgnoreCase(templateCode) || "TPL007".equalsIgnoreCase(templateCode)) {
					content += "Untuk tujuan keselamatan, lampiran PDF dilindungi kata laluan. Untuk membuka fail, taip kata " +
							"laluan anda, yang merupakan nombor pengenalan anda (No.KP, pasport, no. pengenalan polis atau " +
							"tentera yang telah anda berikan sebelum ini). Kata laluan sensitif huruf dan tidak memerlukan " +
							"sengkang atau jarak.<br/><br/>";
					
				} else {
					content += "Untuk tujuan kerahsiaan, lampiran PDF dilindungi kata laluan. Untuk membuka fail, taip kata " +
							"laluan anda, yang merupakan nombor pengenalan anda (No.KP, pasport, no. pengenalan polis atau " +
							"tentera, yang telah anda berikan). Kata laluan sensitif huruf dan tidak memerlukan sengkang " +
							"atau jarak.<br/><br/>";
				}
				
				content += "Contoh ? 123456123456 or A12341234<br/><br/>";
				
				/*if(!cu.isBlank(promoCode)) {
					content += "You are entitled for a RM30* rebate at any of the 50 amusement parks available in " +
							"HappyFun.Asia<br/><br/>";
					
					content += "Your voucher code is " + promoCode + " and it valid until 31st December 2017.<br/><br/>";
					
					content += "*Terms and Conditions apply. Visit " +
							"<a href=\"http://www.happyfun.asia/aia/\">http://www.happyfun.asia/aia/</a> " +
							"for more details.<br/><br/>";
				}*/
				
				content += "Berikut adalah ringkasan maklumat pembelian anda: <br/><br/>";
				
				content += "<strong>Orang Dilindungi:</strong> "+ policyInfo.getOwnerName() +"<br/>";
				content += "<strong>Nombor Telefon:</strong> "+ appForm.getTelNo() +"<br/>";
				content += "<strong>Produk:</strong> "+ appForm.getPlanName() +"<br/>";
				content += "<strong>Nombor Polisi:</strong> "+ policyInfo.getPolicyNo() +"<br/>";
				content += "<strong>Jumlah Premium:</strong> RM "+ policyInfo.getTotalAmount() +"<br/>";
				content += "<strong>Tarikh Polisi:</strong> "+ GenericUtil.dateToStr(policyInfo.getPolicyDate(), 
						"MMM dd, yyyy") +"<br/>";
				content += "<strong>Tarikh Pengeluaran:</strong> "+ GenericUtil.dateToStr(policyInfo.getIssueDate(), 
						"MMM dd, yyyy") +"<br/>";
				
				if("TPL003".equalsIgnoreCase(templateCode)) {
					content += "<strong>Tarikh Matang atau Luput:</strong> "+ 
							GenericUtil.dateToStr(policyInfo.getMaturityDateCICare(), "MMM dd, yyyy") +"<br/>";
					content += "<strong>Tempoh Perlindungan:</strong> Sehingga Orang Dilindungi berumur 80<br/><br/>";
					content += "<strong>Anda telah membeli:</strong><br/><br/>";
					
					content += "<center><table><tr><th>Nama Produk</th><th>Jumlah Perlindungan Asas</th></tr>";
					
					for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
						PolCoverage cov = policyInfo.getCoverages().get(i);
						
						String planType = "Pelan 1";
						if(cov.getBenefitAmount().compareTo(new BigDecimal(100000)) == 0) planType = "Pelan 2";
						if(cov.getBenefitAmount().compareTo(new BigDecimal(150000)) == 0) planType = "Pelan 3";
						if(cov.getBenefitAmount().compareTo(new BigDecimal(200000)) == 0) planType = "Pelan 4";
						
						content += "<tr><td>CI Care Plus</td><td>" + planType +" - RM " + 
									CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
					}
					
					content += "</table></center><br/><br/>";
					
				} else if("TPL006".equalsIgnoreCase(templateCode)|| "TPL007".equalsIgnoreCase(templateCode)){
					content += "<strong>Tarikh Matang atau Luput:</strong> "+ 
							GenericUtil.dateToStr(policyInfo.getMaturityDateCIandMedBasic(), "MMM dd, yyyy") +"<br/>";
					content += "<strong>Tempoh Perlindungan:</strong> Sehingga umur 70 tahun<br/><br/>";
					
				} else {
					content += "<strong>Tarikh Matang atau Luput:</strong> "+ 
							GenericUtil.dateToStr(policyInfo.getExpiryDate(), "MMM dd, yyyy") +"<br/>";
					content += "<strong>Tempoh Perlindungan:</strong> 1 Tahun Sahaja<br/><br/>";
					content += "<strong>Apakah manfaat yang boleh anda nikmati di bawah pelan ini?</strong><br/><br/>";
					
					content += "<center><table><tr><th>Manfaat</th><th>Jumlah Perlindungan Asas</th></tr>";
					
					for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
						PolCoverage cov = policyInfo.getCoverages().get(i);
						if(i == 0) {
							content += "<tr><td>Manfaat Kematian</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						} else if(i == 1) {
							content += "<tr><td>Manfaat Hilang Upaya Secara Menyeluruh dan Kekal</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						}
					}
					
					content += "</table></center><br/><br/>";
				}
				
				if("TPL003".equalsIgnoreCase(templateCode) || "TPL006".equalsIgnoreCase(templateCode) || "TPL007".equalsIgnoreCase(templateCode)) 
					content += "Sila rujuk Helaian Pendedahan Produk dan Sijil Takaful yang dilampirkan bagi senarai faedah yang dilindungi di bawah pelan ini."
							+ "<br/><br/>";
				
				content += "Log masuk ke <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> untuk " +
						"memuat turun kontrak polisi anda, mengemaskinikan maklumat hubungan anda, menukar kaedah dan/atau " +
						"mod pembayaran premium anda, membuat bayaran premium dan banyak lagi.<br/><br/>";
				
				if(!"TPL003".equalsIgnoreCase(templateCode)) {
					content += "Nikmatilah ganjaran kerana membuat pilihan sihat dengan AIA Vitality<br/><br/>";
					content += "Nikmati<br/>";
					content += "<ul><li>Pas filem PERCUMA</li><li>Manfaat Insurans TAMBAHAN</li>" +
							"<li>Potongan 50% bagi manfaat Kesihatan & Perjalanan dan banyak lagi</li></ul><br/>";
					content += "Klik <a href=\"https://www.aia.net.my/AIAVitalityStd/MembershipApplication.aspx\">sini</a> untuk " +
							"mendaftar hari ini dengan hanya RM10 sebulan. Untuk maklumat lanjut, layari " +
							"<a href=\"http://www.aia.com.my/en/our-products/aia-vitality.html\">www.aia.com.my/AIAVitality</a><br/>" +
							"Tertakluk kepada <a href=\"https://www.aiavitality.com.my/vmp-my/\">terma dan syarat</a>.<br/><br/>";
				}
				
				String flpDays = ("TPL003".equalsIgnoreCase(templateCode))? "tiga puluh (30)": "lima belas (15)";
				
				content += "<b><u>Nota Penting</u></b><br/><br/>";
				content += "<b><i>Tempoh Penilaian Percuma</i></b> ? <i>Anda boleh membatalkan polisi anda dengan " +
						"memberitahu kami secara bertulis dan memulangkan kontrak polisi dalam masa " + flpDays + " hari " +
						"selepas anda menerima kontrak polisi. Premium yang telah anda bayar akan dipulangkan, selepas " +
						"ditolak perbelanjaan perubatan yang mungkin anda tanggung.</i><br/><br/>";
				
				content += "Apabila anda menerima kontrak polisi, sila pastikan bahawa semua maklumat dalam kontrak adalah " +
						"lengkap dan tepat. Jika anda tidak memaklumkan kami tentang sebarang ketidaktepatan, kami akan " +
						"menganggap maklumat yang anda isytiharkan dan kemukakan sebagai benar, tepat dan lengkap.<br/><br/>";
				
				content += "Jumlah perlindungan dan manfaat pelan insurans asas dalam Polisi ini diterangkan secara " +
						"terperinci dalam Jadual Perlindungan, Manfaat dan Premium pada Halaman Maklumat Polisi. Semua " +
						"manfaat, pengecualian manfaat, syarat pembayaran dan butiran polisi lain dinyatakan di " +
						"dalamnya.<br/><br/>";
				
				content += "Jika anda perlu membuat tuntutan, sila klik " +
						"<a href=\"http://www.aia.com.my/ms/help-support/claim-guide.html\">sini</a> untuk maklumat " +
						"lanjut.<br/></br/>";
				
				content += "Sekiranya polisi anda menyediakan manfaat kematian, anda juga dinasihatkan untuk membuat penamaan " +
						"dan memastikan penama maklum tentang polisi insurans hayat yang telah anda beli. Tanpa penamaan, " +
						"wang polisi mungkin dibayar kepada wasi atau pentadbir sah harta pusaka anda, tertakluk kepada " +
						"Akta Perkhidmatan Kewangan 2013. Klik  " +
						"<a href=\"https://www.aia.com.my/ms/help-support.html?auto=30&q=nomi\">sini</a> untuk mengetahui " +
						"caranya.<br/><br/>";
				
				String aiaPhone = (!"TPL003".equalsIgnoreCase(templateCode))? "1300 88 1899": "1800 38 3464";
				
				content += "Jika anda mempunyai apa-apa soalan, sila hubungi kami di:<br/>";
				content += "AIA Bhd - " + aiaPhone + "<br/>";
				
				if(!"TPL003".equalsIgnoreCase(templateCode))
					content += "AIA PUBLIC Takaful Bhd. ? 1 300 88 8922<br/><br/>";
				else
					content += "<br/>";
				
				content += "Waktu operasi kami:<br/>";
				content += "Isnin hingga Khamis 8.30pg - 5.30ptg<br/>";
				content += "Jumaat 8.30pg - 4.30ptg<br/><br/>";
				
				content += "Terima kasih dan semoga anda melalui pengalaman baik dengan My AIA.<br/><br/><br/>";
				
				content += "</font></body></html>";
				
			} else {
				content += "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title></title>" +
						"<style>table { font-family: verdana, sans-serif; border-collapse: collapse; " +
						"width: 90%; font-size: 11px; } th { border: 1px solid gray; text-align: left; padding: 8px; " +
						"background-color: #dddddd; } td { border: 1px solid gray; text-align: left; " +
						"padding: 8px; } </style></head><body>";
				content += "<font face=\"verdana\" size=\"2\">";
				
				content += "Dear " + policyInfo.getOwnerName() + ",<br/><br/>";
			
				content += "We are pleased to enclose your policy document for your viewing. Your policy document will also " +
						"be available on <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> within 24 " +
						"hours after you have purchased your policy.<br/><br/>";
				
				if("TPL003".equalsIgnoreCase(templateCode) || "TPL006".equalsIgnoreCase(templateCode) || "TPL007".equalsIgnoreCase(templateCode)) {
					content += "For security, the PDF attachment is password protected. " +
							"To view it, key in your password, which is your identification number (e.g. NRIC, " +
							"passport number, police or army identification provided by you). The password is case " +
							"sensitive and requires no hyphen or space.<br/><br/>";
					
				} else {
					content += "For confidentiality, the PDF attachment is password protected. " +
							"To view it, key in your password, which is your identification number (NRIC, passport, police or " +
							"army identification, whichever you provided). The password is case sensitive and requires no " +
							"hyphen or space.<br/><br/>";
				}
				
				content += "Example ? 123456123456 or A12341234<br/><br/>";
				
				if(!cu.isBlank(promoCode)) {
					content += "You are entitled for a RM30* rebate at any of the 50 amusement parks available in " +
							"HappyFun.Asia<br/><br/>";
					
					content += "Your voucher code is " + promoCode + " and it valid until 31st January 2018.<br/><br/>";
					
					content += "*Terms and Conditions apply. Visit " +
							"<a href=\"http://www.happyfun.asia/aia/\">http://www.happyfun.asia/aia/</a> " +
							"for more details.<br/><br/>";
				}
				
				content += "Below is a summary of your purchase details: <br/><br/>";
				
				content += "<strong>Person Covered:</strong> "+ policyInfo.getOwnerName() +"<br/>";
				//content += "<strong>NRIC:</strong> "+ policyInfo.getOwnerMykad() +"<br/>";
				content += "<strong>Mobile Number:</strong> "+ appForm.getTelNo() +"<br/>";
				content += "<strong>Product:</strong> "+ appForm.getPlanName() +"<br/>";
				content += "<strong>Policy Number:</strong> "+ policyInfo.getPolicyNo() +"<br/>";
				content += "<strong>Total Premium:</strong> RM "+ policyInfo.getTotalAmount() +"<br/>";
				content += "<strong>Policy Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getPolicyDate(), 
						"MMM dd, yyyy") +"<br/>";
				content += "<strong>Issuance Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getIssueDate(), 
						"MMM dd, yyyy") +"<br/>";
				
				if("TPL003".equalsIgnoreCase(templateCode)) {
					content += "<strong>Maturity or Expiry Date:</strong> "+ 
							GenericUtil.dateToStr(policyInfo.getMaturityDateCICare(), "MMM dd, yyyy") +"<br/>";
					content += "<strong>Coverage Duration:</strong> Up to Insured's Age 80<br/><br/>";
					content += "<strong>You have purchased:</strong><br/><br/>";
					
					content += "<center><table><tr><th>Product Name</th><th>Basic Coverage Amount</th></tr>";
					
					for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
						PolCoverage cov = policyInfo.getCoverages().get(i);
						
						String planType = "Plan 1";
						if(cov.getBenefitAmount().compareTo(new BigDecimal(100000)) == 0) planType = "Plan 2";
						if(cov.getBenefitAmount().compareTo(new BigDecimal(150000)) == 0) planType = "Plan 3";
						if(cov.getBenefitAmount().compareTo(new BigDecimal(200000)) == 0) planType = "Plan 4";
						
						content += "<tr><td>CI Care Plus</td><td>" + planType +" - RM " + 
									CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
					}
					
					content += "</table></center><br/><br/>";
					
				} else if("TPL006".equalsIgnoreCase(templateCode) || "TPL007".equalsIgnoreCase(templateCode)) {
					content += "<strong>Maturity or Expiry Date:</strong> "+ 
							GenericUtil.dateToStr(policyInfo.getMaturityDateCIandMedBasic(), "MMM dd, yyyy") +"<br/>";
					content +="<strong>Coverage Duration:</strong> Up to age 70<br/><br/>";
					
				} else {
					content += "<strong>Maturity or Expiry Date:</strong> "+ 
							GenericUtil.dateToStr(policyInfo.getExpiryDate(), "MMM dd, yyyy") +"<br/>";
					content += "<strong>Coverage Duration:</strong> 1 Year Only<br/><br/>";
					content += "<strong>What are your benefits under this plan?</strong><br/><br/>";
					
					content += "<center><table><tr><th>Benefits</th><th>Basic Coverage Amount</th></tr>";
					
					for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
						PolCoverage cov = policyInfo.getCoverages().get(i);
						if(i == 0) {
							content += "<tr><td>Death Benefit</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						} else if(i == 1) {
							content += "<tr><td>Total and Permanent Disability Benefit</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						}
					}
					
					content += "</table></center><br/><br/>";
				}
				
				if("TPL003".equalsIgnoreCase(templateCode) || "TPL006".equalsIgnoreCase(templateCode) || "TPL007".equalsIgnoreCase(templateCode))
					content += "Please refer to the Product Disclosure Sheet and Takaful Certificate attached for the list of benefits covered under this plan."
							+ "<br/><br/>";
				
				content += "Log in to <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> to download your " +
						"policy contract, update your contact details, change your premium payment method and/or frequency, " +
						"make your premium payments and much more.<br/><br/>";
				
				if(!"TPL003".equalsIgnoreCase(templateCode)) {
					content += "Get rewarded for your healthy choices with AIA Vitality<br/><br/>";
					content += "Enjoy<br/>";
					content += "<ul><li>FREE movie passes</li><li>EXTRA insurance benefits</li>" +
							"<li>Up to 50% off Health & travel benefits and more</li></ul><br/>";
					content += "Click <a href=\"https://www.aia.net.my/AIAVitalityStd/MembershipApplication.aspx\">here</a> to " +
							"sign up today for only RM10 per month. For more info, visit " +
							"<a href=\"https://www.aia.com.my/en/our-products/aia-vitality.html\">www.aia.com.my/AIAVitality</a><br/>" +
							"<a href=\"https://www.aiavitality.com.my/vmp-my/\">Terms and conditions</a> apply.<br/><br/>";
				}
				
				String flpDays = ("TPL003".equalsIgnoreCase(templateCode))? "thirty (30)": "fifteen (15)";
				
				content += "<b><u>Important Notes</u></b><br/><br/>";
				content += "<b><i>Free Look Period</i></b> ? <i>You may cancel your policy by writing in to us and returning " +
						"your policy contract within " + flpDays + " days after you have received your policy contract. The " +
						"premiums that you have paid will be refunded, after deducting any medical expenses you may " +
						"have incurred.</i><br/><br/>";
				
				content += "Once you receive your policy contract, please ensure that all the information in the contract is " +
						"complete and accurate. If you do not notify us of any inaccuracies, we will take the information that " +
						"was declared and submitted by you and/or your authorised representative as true, accurate and " +
						"complete.<br/><br/>";
				
				content += "The coverage amount and benefits of this Policy are detailed in the Schedule of Coverage, " +
						"Benefits and Premiums on the Policy Information Page. All benefits, benefit exclusions, conditions " +
						"for payment and other policy details are set out inside.<br/><br/>";
				
				content += "If you need to make a claim, please click " +
						"<a href=\"http://www.aia.com.my/en/help-support/claim-guide.html\">here</a> to find out " +
						"how to do so.<br/></br/>";
				
				content += "If your policy provides death benefit, it is also advisable to nominate a nominee and ensure that " +
						"the nominee is aware of the life insurance policy that you have purchased. Without a nomination, " +
						"policy moneys may be paid to the lawful executor or administrator of your estate, subject to the " +
						"Financial Services Act 2013. Click " +
						"<a href=\"https://www.aia.com.my/en/help-support.html?auto=30&q=nomi\">here</a> to find out " +
						"how.<br/><br/>";
				
				String aiaPhone = (!"TPL003".equalsIgnoreCase(templateCode))? "1300 88 1899": "1800 38 3464";
				
				content += "If you have any questions, please Contact Us at: <br/>";
				content += "AIA Bhd - " + aiaPhone + "<br/>";
				
				if(!"TPL003".equalsIgnoreCase(templateCode))
					content += "AIA PUBLIC Takaful Bhd. ? 1 300 88 8922<br/><br/>";
				else
					content += "<br/>";
				
				content += "Our operating hours are:<br/>";
				content += "Monday to Thursday 8.30am - 5.30pm<br/>";
				content += "Friday 8.30am - 4.30pm<br/><br/>";
				
				content += "Thank you and enjoy your experience with My AIA.<br/><br/><br/>";
				
				content += "</font></body></html>";
			}
		} catch(Exception ex) {
			System.out.println("[UploadALPP.processContent] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return content;
	}
	
	private String processTkfContent(String companyCode, PolicyInfo policyInfo, AppForm appForm, String promoCode, String templateCode) {
		String content = "";
		CommonFileUtil cu = new CommonFileUtil();
		
		try {
			if("MS".equalsIgnoreCase(appForm.getPolLanguage())) {
				content += "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title></title>" +
						"<style>table { font-family: verdana, sans-serif; border-collapse: collapse; " +
						"width: 90%; font-size: 11px; } th { border: 1px solid gray; text-align: left; padding: 8px; " +
						"background-color: #dddddd; } td { border: 1px solid gray; text-align: left; " +
						"padding: 8px; } </style></head><body>";
				content += "<font face=\"verdana\" size=\"2\">";
				
				content += "Kepada " + policyInfo.getOwnerName() + ",<br/><br/>";
				
				content += "Kami dengan sukacitanya melampirkan sijil Takaful anda untuk tatapan anda. Sijil Takaful anda " +
						"juga boleh didapati di <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> " +
						"dalam masa 24 jam selepas anda membayar untuk penyertaan anda.<br/><br/>";
				
				content += "Untuk tujuan kerahsiaan, lampiran PDF dilindungi kata laluan. Untuk membuka fail, taip kata " +
						"laluan anda, yang merupakan nombor pengenalan anda (No.KP, pasport, no. pengenalan polis atau " +
						"tentera, yang telah anda berikan). Kata laluan sensitif huruf dan tidak memerlukan sengkang " +
						"atau jarak.<br/><br/>";
				
				content += "Contoh ? 123456123456 or A12341234<br/><br/>";
				
				/*if(!cu.isBlank(promoCode)) {
					content += "You are entitled for a RM30* rebate at any of the 50 amusement parks available in " +
							"HappyFun.Asia<br/><br/>";
					
					content += "Your voucher code is " + promoCode + " and it valid until 31st December 2017.<br/><br/>";
					
					content += "*Terms and Conditions apply. Visit " +
							"<a href=\"http://www.happyfun.asia/aia/\">http://www.happyfun.asia/aia/</a> " +
							"for more details.<br/><br/>";
				}*/
				
				content += "Berikut adalah ringkasan maklumat pembelian anda: <br/><br/>";
				
				content += "<strong>Orang Dilindungi:</strong> "+ policyInfo.getOwnerName() +"<br/>";
				content += "<strong>Nombor Telefon:</strong> "+ appForm.getTelNo() +"<br/>";
				content += "<strong>Produk:</strong> "+ appForm.getPlanName() +"<br/>";
				content += "<strong>Sijil Takaful:</strong> "+ policyInfo.getPolicyNo() +"<br/>";
				content += "<strong>Jumlah Caruman:</strong> RM "+ policyInfo.getTotalAmount() +"<br/>";
				content += "<strong>Tarikh Sijil:</strong> "+ GenericUtil.dateToStr(policyInfo.getPolicyDate(), 
						"MMM dd, yyyy") +"<br/>";
				content += "<strong>Tarikh Penyertaan:</strong> "+ GenericUtil.dateToStr(policyInfo.getIssueDate(), 
						"MMM dd, yyyy") +"<br/>";
				
				if("TPL006".equalsIgnoreCase(templateCode) ||"TPL007".equalsIgnoreCase(templateCode)){
					content += "<strong>Tarikh Matang atau Tamat:</strong> "+ GenericUtil.dateToStr(policyInfo.getMaturityDateCIandMedBasic(), 
							"MMM dd, yyyy") +"<br/>";
					content +="<strong>Tempoh Perlindungan:</strong> Sehingga umur 70 tahun<br/><br/>";
					content += "Sila rujuk Helaian Pendedahan Produk dan Sijil Takaful yang dilampirkan bagi senarai faedah yang dilindungi di bawah pelan ini."
							+ "<br/><br/>";
					
				} else{
					content += "<strong>Tarikh Matang atau Tamat:</strong> "+ GenericUtil.dateToStr(policyInfo.getExpiryDate(), 
							"MMM dd, yyyy") +"<br/>";
					content += "<strong>Tempoh Perlindungan:</strong> 1 Tahun Sahaja<br/><br/>";
					
					content += "<strong>Apakah faedah yang boleh anda nikmati di bawah pelan ini?</strong><br/><br/>";
					content += "<center><table><tr><th>Faedah</th><th>Amaun Perlindungan Asas</th></tr>";
					for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
						PolCoverage cov = policyInfo.getCoverages().get(i);
						if(i == 0) {
							content += "<tr><td>Faedah Kematian</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						} else if(i == 1) {
							content += "<tr><td>Faedah Hilang Upaya Secara Menyeluruh dan Kekal</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						}
					}
					
					content += "</table></center><br/><br/>";
				}
				
				content += "Log masuk ke <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> untuk " +
						"memuat turun sijil Takaful anda, mengemaskini maklumat anda untuk dihubungi, menukar kaedah dan/atau " +
						"mod pembayaran caruman anda, membuat bayaran caruman dan banyak lagi.<br/><br/>";
				
				content += "Nikmatilah ganjaran kerana membuat pilihan sihat dengan AIA Vitality<br/><br/>";
				content += "Nikmati<br/>";
				content += "<ul><li>Pas filem PERCUMA</li><li>Faedah Takaful TAMBAHAN</li>" +
						"<li>Potongan 50% bagi faedah Kesihatan &amp; Perjalanan dan banyak lagi</li></ul><br/>";
				content += "Klik <a href=\"https://www.aia.net.my/AIAVitalityStd/MembershipApplication.aspx\">sini</a> untuk " +
						"mendaftar hari ini dengan hanya RM10 sebulan. Untuk maklumat lanjut, layari " +
						"<a href=\"http://www.aia.com.my/en/our-products/aia-vitality.html\">www.aia.com.my/AIAVitality</a><br/>" +
						"Tertakluk kepada <a href=\"https://www.aiavitality.com.my/vmp-my/\">terma dan syarat</a>.<br/><br/>";
				
				content += "<b><u>Nota Penting</u></b><br/><br/>";
				content += "<b><i>Tempoh Penilaian Percuma</i></b> ? <i>Anda boleh membatalkan sijil Takaful anda dengan " +
						"memberitahu kami secara bertulis dan memulangkan sijil Takaful dalam masa lima belas (15) hari " +
						"selepas anda menerima sijil. Caruman yang telah anda bayar akan dipulangkan, selepas " +
						"ditolak perbelanjaan perubatan yang mungkin anda tanggung.</i><br/><br/>";
				
				content += "Apabila anda menerima sijil Takaful, sila pastikan bahawa semua maklumat dalam sijil adalah " +
						"lengkap dan tepat. Jika anda tidak memaklumkan kami tentang sebarang ketidaktepatan, kami akan " +
						"menganggap maklumat yang anda isytiharkan dan kemukakan sebagai benar, tepat dan lengkap.<br/><br/>";
				
				content += "Amaun perlindungan dan faedah pelan Takaful asas ini dan sebarang kontrak tambahan dalam " +
						"Sijil ini diterangkan secara terperinci dalam Jadual Faedah dan Caruman pada " +
						"Halaman Maklumat Sijil. Semua faedah, pengecualian faedah, syarat pembayaran dan butiran " +
						"sijil lain dinyatakan di dalamnya.<br/><br/>";
				
				content += "Jika anda perlu membuat tuntutan, sila klik " +
						"<a href=\"http://www.aia.com.my/ms/help-support/claim-guide.html\">sini</a> untuk maklumat " +
						"lanjut.<br/></br/>";
				
//				content += "Anda boleh menetapkan penama untuk menerima faedah Takaful yang dibayar setelah kematian anda " +
//						"di bawah Sijil Takaful, sama ada sebagai seorang Wasi (Pelaksana), atau sebagai seorang " +
//						"benefisiari di bawah Hibah Bersyarat (Hadiah). Klik  " +
//						"<a href=\"https://www.aia.com.my/ms/help-support.html?auto=30&q=nomi\">sini</a> untuk mengetahui " +
//						"caranya.<br/><br/>";
				
				content += "Jika anda mempunyai apa-apa soalan, sila hubungi kami di:<br/>";
				content += "AIA Bhd ? 1 300 88 1899<br/>";
				content += "AIA PUBLIC Takaful Bhd. ? 1 300 88 8922<br/><br/>";
				
				content += "Waktu operasi kami:<br/>";
				content += "Isnin hingga Khamis 8.30pg - 5.30ptg<br/>";
				content += "Jumaat 8.30pg - 4.30ptg<br/><br/>";
				
				content += "Terima kasih dan semoga anda menikmati pengalaman baik dengan My AIA.<br/><br/><br/>";
				
				content += "</font></body></html>";
				
			} else {
				content += "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><title></title>" +
						"<style>table { font-family: verdana, sans-serif; border-collapse: collapse; " +
						"width: 90%; font-size: 11px; } th { border: 1px solid gray; text-align: left; padding: 8px; " +
						"background-color: #dddddd; } td { border: 1px solid gray; text-align: left; " +
						"padding: 8px; } </style></head><body>";
				content += "<font face=\"verdana\" size=\"2\">";
				
				content += "Dear " + policyInfo.getOwnerName() + ",<br/><br/>";
				
				content += "We are pleased to enclose your Takaful certificate for your viewing. Your Takaful certificate " +
						"will also be available on <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> " +
						"within 24 hours after you have made payment for your participation.<br/><br/>";
				
				content += "For confidentiality, the PDF attachment is password protected. To view it, key in your password, " +
						"which is your identification number (NRIC, passport, police or army identification, whichever you " +
						"provided). The password is case sensitive and requires no hyphen or space.<br/><br/>";
				
				content += "Example ? 123456123456 or A12341234<br/><br/>";
				
				if(!cu.isBlank(promoCode)) {
					content += "You are entitled for a RM30* rebate at any of the 50 amusement parks available in " +
							"HappyFun.Asia<br/><br/>";
					
					content += "Your voucher code is " + promoCode + " and it valid until 31st January 2018.<br/><br/>";
					
					content += "*Terms and Conditions apply. Visit " +
							"<a href=\"http://www.happyfun.asia/aia/\">http://www.happyfun.asia/aia/</a> " +
							"for more details.<br/><br/>";
				}
				
				content += "Below is a summary of your participation details: <br/><br/>";
				
				content += "<strong>Person Covered:</strong> "+ policyInfo.getOwnerName() +"<br/>";
				//content += "<strong>NRIC:</strong> "+ policyInfo.getOwnerMykad() +"<br/>";
				content += "<strong>Mobile Number:</strong> "+ appForm.getTelNo() +"<br/>";
				content += "<strong>Product:</strong> "+ appForm.getPlanName() +"<br/>";
				content += "<strong>Certificate Number:</strong> "+ policyInfo.getPolicyNo() +"<br/>";
				content += "<strong>Total Contribution:</strong> RM "+ policyInfo.getTotalAmount() +"<br/>";
				content += "<strong>Certificate Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getPolicyDate(), 
						"MMM dd, yyyy") +"<br/>";
				content += "<strong>Issuance Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getIssueDate(), 
						"MMM dd, yyyy") +"<br/>";
				
				if("TPL006".equalsIgnoreCase(templateCode) || "TPL007".equalsIgnoreCase(templateCode)) {
					content += "<strong>Maturity or Expiry Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getMaturityDateCIandMedBasic(), 
							"MMM dd, yyyy") +"<br/>";
					content +="<strong>Coverage Duration:</strong> Up to age 70<br/><br/>";
					content += "Please refer to the Product Disclosure Sheet and Takaful Certificate attached for the list of benefits covered under this plan."
							+ "<br/><br/>";
					
				} else {
					content += "<strong>Maturity or Expiry Date:</strong> "+ GenericUtil.dateToStr(policyInfo.getExpiryDate(), 
							"MMM dd, yyyy") +"<br/>";
					content += "<strong>Coverage Duration:</strong> 1 Year Only<br/><br/>";
					
					content += "<strong>What are your benefits under this plan?</strong><br/><br/>";
					content += "<center><table><tr><th>Benefits</th><th>Basic Coverage Amount</th></tr>";
					for(int i = 0; i < policyInfo.getCoverages().size(); i++) {
						PolCoverage cov = policyInfo.getCoverages().get(i);
						if(i == 0) {
							content += "<tr><td>Death Benefit</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						} else if(i == 1) {
							content += "<tr><td>Total and Permanent Disability Benefit</td>" +
									"<td>RM " + CommonUtil.getMoneyFormat(cov.getBenefitAmount(), 0) + "</td></tr>";
						}
					}
					
					content += "</table></center><br/><br/>";
				}
				
				content += "Login to <a href=\"https://www.aia.com.my/en/my-aia/myaia-login.html\">My AIA</a> to download your " +
						"Takaful certificate, update your contact details, change your contribution payment method and/or mode, " +
						"pay your contribution and much more.<br/><br/>";
				
				content += "Get rewarded for your healthy choices with AIA Vitality<br/><br/>";
				content += "Enjoy<br/>";
				content += "<ul><li>FREE movie passes</li><li>EXTRA Takaful benefits</li>" +
						"<li>Up to 50% off Health & travel benefits and more</li></ul><br/>";
				content += "Click <a href=\"https://www.aia.net.my/AIAVitalityStd/MembershipApplication.aspx\">here</a> to " +
						"sign up today for only RM10 per month. For more info, visit " +
						"<a href=\"http://www.aia.com.my/en/our-products/aia-vitality.html\">www.aia.com.my/AIAVitality</a><br/>" +
						"<a href=\"https://www.aiavitality.com.my/vmp-my/\">Terms and conditions</a> apply.<br/><br/>";
				
				content += "<b><u>Important Notes</u></b><br/><br/>";
				content += "<b><i>Free Look Period</i></b> ? <i>You have the right to cancel your Takaful certificate by giving " +
						"us a written request to AIA PUBLIC Takaful Bhd. within fifteen (15) days after you have received your " +
						"Takaful certificate. The contribution that you have paid will be refunded to you.</i><br/><br/>";
				
				content += "Once you receive your Takaful certificate, please ensure that all the information in the " +
						"certificate is complete and accurate. If you do not notify us of any inaccuracies, we will take the " +
						"information that was declared and submitted by you as true, accurate and complete.<br/><br/>";
				
				content += "The coverage amount and benefits of this Takaful plan and any supplementary contracts in this " +
						"Certificate are detailed in the Schedule of Benefits and Contributions on the Certificate " +
						"Information Page. All benefits, benefit exclusions, conditions for payment and other certificate " +
						"details are set out inside.<br/><br/>";
				
				content += "If you need to make a claim, please click " +
						"<a href=\"http://www.aia.com.my/en/help-support/claim-guide.html\">here</a> to find out " +
						"how to do so.<br/></br/>";
				
//				content += "You may designate nominee(s) to receive Takaful benefits payable upon your death, if applicable " +
//						"under the Takaful Certificate, either a Wasi (Executor), or as a beneficiary under a " +
//						"Conditional Hibah (Gift). Click " +
//						"<a href=\"https://www.aia.com.my/en/help-support.html?auto=30&q=nomi\">here</a> " +
//						"to find out how.<br/><br/>";
				
				content += "If you have any questions, please contact us at:<br/>";
				content += "AIA Bhd ? 1 300 88 1899<br/>";
				content += "AIA PUBLIC Takaful Bhd. ? 1 300 88 8922<br/><br/>";
				
				content += "Our operating hours are: <br/><br/>";
				content += "Monday to Thursday 8.30am - 5.30pm<br/>";
				content += "Friday 8.30am - 4.30pm<br/><br/>";
				
				content += "Thank you and enjoy your experience with My AIA.<br/><br/><br/>";
				
				content += "</font></body></html>";
			}
		} catch(Exception ex) {
			System.out.println("[UploadALPP.processTkfContent] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return content;
	}
	
	private String getPromoCode(String templateCode) {
		/*final String alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		final int N = alphabet.length();
		
		Random r = new Random();
		
		String promoCode = "";
		for (int i = 0; i < 9; i++) {
			promoCode += alphabet.charAt(r.nextInt(N));
		}*/
		
		DBCommon dc = new DBCommon();
		String promoCode = dc.getPromoCode(templateCode);
		
		return promoCode;
	}
}