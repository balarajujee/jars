package com.aia.service;

import ho.aia.utility.host.PasswordFile;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.Random;
import java.util.ResourceBundle;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericUtil;

public class UploadWF {
	public void upload(Map<String, ByteArrayOutputStream> pdfBaosMap, String companyCode, String policyNo, boolean isWebForm) {
		try {
			Random rand = new Random();
			int randomNum = rand.nextInt((9 - 0) + 1) + 0;
			
			ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
			String pfvHome = bundle.getString("PFVHomeDirectory");
			
			String pfvPath = pfvHome + "/" + companyCode + "/98/Images";
			String confPath = pfvHome + "/" + companyCode + "/98";
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd hhmmssSSS" + randomNum + " aa");
			String pfvFileFormat = "RUNI " + sdf.format(new Date());
			
			// process PDF
			String fullPDFName = pfvFileFormat + "_Contract_01.PDF";
			uploadSmbFile(getFullPDF(pdfBaosMap), pfvPath + "/" + fullPDFName);
			
			//Thread.sleep(10000);
			
			// process TIFF
			if(!isWebForm) {
				List<String> pdsTiffNames = processTIFF(pdfBaosMap, CommonFileUtil.PDS, pfvPath, pfvFileFormat);
				List<String> apfTiffNames = processTIFF(pdfBaosMap, CommonFileUtil.APF, pfvPath, pfvFileFormat);
				
				// process XML
				ByteArrayOutputStream xmlBaos = processXMLforPFV(pfvFileFormat, fullPDFName, pdsTiffNames, 
						apfTiffNames, companyCode, policyNo);
				uploadSmbFile(xmlBaos, confPath + "/" + pfvFileFormat + ".xml");
				
			} else {
				List<String> conTiffNames = processTIFF(pdfBaosMap, CommonFileUtil.CON, pfvPath, pfvFileFormat);
				
				// process XML
				ByteArrayOutputStream xmlBaos = processWebFormXMLforPFV(pfvFileFormat, fullPDFName, conTiffNames, 
						companyCode, policyNo);
				uploadSmbFile(xmlBaos, confPath + "/" + pfvFileFormat + ".xml");
			}
			
			// process TRG
			ByteArrayOutputStream trgBaos = new ByteArrayOutputStream();
			uploadSmbFile(trgBaos, confPath + "/" + pfvFileFormat + ".trg");
			
		} catch(Exception ex) {
			System.out.println("[UploadWF.upload] Exception: " + ex.toString());
			ex.printStackTrace();
			
		} finally {
			pdfBaosMap = null;
		}
	}

	protected List<String> processTIFF(Map<String, ByteArrayOutputStream> pdfBaosMap, String fileFormat, 
			String pfvPath, String pfvFileFormat) {
		CommonFileUtil cu = new CommonFileUtil();
		List<String> tiffNames = new ArrayList<String>();
		
		try {
			ByteArrayOutputStream pdsBaos = pdfBaosMap.get(fileFormat);
			List<ByteArrayOutputStream> pdsTiffs = cu.pdfToTiff(pdsBaos);
			
			int i = 1;
			for(ByteArrayOutputStream pdsTiff: pdsTiffs) {
				String tiffName = pfvFileFormat + "_" + fileFormat + "_Page_" + i++ +".TIF";
				uploadSmbFile(pdsTiff, pfvPath + "/" + tiffName);
				
				tiffNames.add(tiffName);
			}
		} catch(Exception ex) {
			System.out.println("[UploadWF.processTIFF] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return tiffNames;
	}
	
	protected ByteArrayOutputStream getFullPDF(Map<String, ByteArrayOutputStream> pdfBaosMap) {
		CommonFileUtil cu = new CommonFileUtil();
		GenericUtil gu = new GenericUtil();
		
		ByteArrayOutputStream fullPdfBaos = new ByteArrayOutputStream();
		
		try {
			if(!cu.isBlank(pdfBaosMap)) {
				Iterator<Map.Entry<String, ByteArrayOutputStream>> it = pdfBaosMap.entrySet().iterator();
				
				while(it.hasNext()) {
					Map.Entry<String, ByteArrayOutputStream> pair = (Map.Entry<String, ByteArrayOutputStream>) it.next();
					//String templCode = pair.getKey();
					ByteArrayOutputStream pdfBaos = pair.getValue();
					
					fullPdfBaos = gu.combinePDF(fullPdfBaos, pdfBaos);
				}
			}
		} catch(Exception ex) {
			System.out.println("[UploadWF.getFullPDF] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return fullPdfBaos;
	}
	
	protected synchronized void uploadSmbFile(ByteArrayOutputStream baos, String pathFile) {
		try {
			InputStream fis = new ByteArrayInputStream(baos.toByteArray());
			
			ResourceBundle bundle = PropertyResourceBundle.getBundle("dbConnect");
			PasswordFile pwdFile = 
					new PasswordFile(bundle.getString("DatabasePasswordFileDirectory"), "PFVUSR", "USER", "PASSWD");
			
			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication("", pwdFile.getUserId(), pwdFile.getPassword());
			
			SmbFile remoteFile = new SmbFile(pathFile, auth);
			remoteFile.connect(); //Try to connect
	        
	        OutputStream out = new BufferedOutputStream(new SmbFileOutputStream(remoteFile));
	        
	        byte[] buffer = new byte[4096];
	        int len = 0; //Read length
	        while ((len = fis.read(buffer)) != -1) {
	            out.write(buffer, 0, len);
	        }
	        
	        out.flush();
	        
	        Timestamp ts = new Timestamp(System.currentTimeMillis());
	        System.out.println(ts + " Uploaded to PFV: " + pathFile);
	        
		} catch(Exception ex) {
			System.out.println("[UploadWF.uploadSmbFile] Exception: " + ex.toString());
			ex.printStackTrace();
		}
	}
	
	private ByteArrayOutputStream processXMLforPFV(String pfvFileFormat, String fullPDFName, 
			List<String> pdsTiffNames, List<String> apfTiffNames, String companyCode, String policyNo) {
		ByteArrayOutputStream xmlBaos = new ByteArrayOutputStream();
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String currentDate = sdf.format(new Date());
			
			String policyPrefix = policyNo.substring(0, 3) + "  " + policyNo.substring(3, policyNo.length());
			String policyNoFolder = policyPrefix + "R";
			String policyNoPDF = policyPrefix + "FNSL30F";
			String policyNoAPF = policyPrefix + "ANSL10N";
			String policyNoPDS = policyPrefix + "ANSL20N";
			
			Document doc = DocumentHelper.createDocument();
			
			Element root = doc.addElement("XML");
			
			Element docx = root.addElement("DOCX");
			docx.addAttribute("VERSION", "1");
			docx.addAttribute("WORKDIR", "\\" + companyCode + "\\98\\Images");
			
			Element batch = docx.addElement("BATCH");
			batch.addAttribute("NAME", pfvFileFormat);
			batch.addAttribute("CLASS", "RUNI");
			
			batch.addElement("INDEX").addAttribute("FIELD", "BoxNo").setText("EAPP-IMP");
			batch.addElement("INDEX").addAttribute("FIELD", "BatchSeqNo").setText("999999");
			batch.addElement("INDEX").addAttribute("FIELD", "Branch").setText("98");
			batch.addElement("INDEX").addAttribute("FIELD", "ReceivedDate").setText(currentDate);
			batch.addElement("INDEX").addAttribute("FIELD", "LFCM").setText(currentDate);
			batch.addElement("INDEX").addAttribute("FIELD", "ProcessType").setText("RUNI");
			batch.addElement("INDEX").addAttribute("FIELD", "BatchCycle").setText(currentDate);
			
			Element folder = batch.addElement("FOLDER").addAttribute("NAME", policyNoFolder).addAttribute("CLASS", "FLD_UNI04");
			
			folder.addElement("INDEX").addAttribute("FIELD", "FatherPolicyNo").setText(policyNo);
			folder.addElement("INDEX").addAttribute("FIELD", "SonPolicyNo").setText("");
			folder.addElement("INDEX").addAttribute("FIELD", "AgentCode1").setText("83587");
			folder.addElement("INDEX").addAttribute("FIELD", "AgentCode2").setText("");
			folder.addElement("INDEX").addAttribute("FIELD", "ClaimAmount").setText("0");
			folder.addElement("INDEX").addAttribute("FIELD", "OriginalDomain").setText("KLIW");
			folder.addElement("INDEX").addAttribute("FIELD", "Rescan").setText("N");
			folder.addElement("INDEX").addAttribute("FIELD", "Signature").setText("Y");
			folder.addElement("INDEX").addAttribute("FIELD", "MedCode").setText("0");
			folder.addElement("INDEX").addAttribute("FIELD", "ExpirationDays").setText("0");
			folder.addElement("INDEX").addAttribute("FIELD", "Magnum").setText("N");
			folder.addElement("INDEX").addAttribute("FIELD", "BoxNo").setText("EAPP-IMP");
			folder.addElement("INDEX").addAttribute("FIELD", "BatchSeqNo").setText("999999");
			folder.addElement("INDEX").addAttribute("FIELD", "Branch").setText("98");
			folder.addElement("INDEX").addAttribute("FIELD", "ReceivedDate").setText(currentDate);
			folder.addElement("INDEX").addAttribute("FIELD", "LFCM").setText(currentDate);
			folder.addElement("INDEX").addAttribute("FIELD", "ProcessType").setText("RUNI");
			folder.addElement("INDEX").addAttribute("FIELD", "BatchCycle").setText(currentDate);
			
			// Contract PDF
			Element docEle = folder.addElement("DOC").addAttribute("NAME", policyNoPDF)
					.addAttribute("CLASS", "DOC_UNI05").addAttribute("REFER", "");
			
			List<String> pageNames = new ArrayList<String>();
			pageNames.add(fullPDFName);
			
			generateDocElement(docEle, "SL311169", "Fil", currentDate, pageNames, policyNo);
			
			// APF TIFF
			docEle = folder.addElement("DOC").addAttribute("NAME", policyNoAPF)
					.addAttribute("CLASS", "DOC_UNI05").addAttribute("REFER", "");
			
			generateDocElement(docEle, "SL111163", "No", currentDate, apfTiffNames, policyNo);
			
			// PDS TIFF
			docEle = folder.addElement("DOC").addAttribute("NAME", policyNoPDS)
					.addAttribute("CLASS", "DOC_UNI05").addAttribute("REFER", "");
			
			generateDocElement(docEle, "SL211166", "No", currentDate, pdsTiffNames, policyNo);
			
			folder.addElement("INDEX").addAttribute("FIELD", "eSubmission").setText("Y");
			
			// Pretty print the document to baos
	        OutputFormat format = OutputFormat.createPrettyPrint();
	        XMLWriter writer = new XMLWriter(xmlBaos, format);
	        writer.write(doc);
	        writer.flush();
			
			//System.out.println("xml: " + doc.asXML().replaceAll("\n", ""));
			//doc.asXML().toString().getBytes();
			
		} catch(Exception ex) {
			System.out.println("[UploadWF.processXMLforPFV] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return xmlBaos;
	}
	
	private ByteArrayOutputStream processWebFormXMLforPFV(String pfvFileFormat, String fullPDFName, 
			List<String> conTiffNames, String companyCode, String policyNo) {
		ByteArrayOutputStream xmlBaos = new ByteArrayOutputStream();
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String currentDate = sdf.format(new Date());
			
			String policyPrefix = policyNo.substring(0, 3) + "  " + policyNo.substring(3, policyNo.length());
			String policyNoFolder = policyPrefix + "R";
			String policyNoPDF = policyPrefix + "FNV170F";
			String policyNoTIF = policyPrefix + "ANV170N";
			
			Document doc = DocumentHelper.createDocument();
			
			Element root = doc.addElement("XML");
			
			Element docx = root.addElement("DOCX");
			docx.addAttribute("VERSION", "1");
			docx.addAttribute("WORKDIR", "\\" + companyCode + "\\98\\Images");
			
			Element batch = docx.addElement("BATCH");
			batch.addAttribute("NAME", pfvFileFormat);
			batch.addAttribute("CLASS", "RUNI");
			
			batch.addElement("INDEX").addAttribute("FIELD", "BoxNo").setText("EAPP-IMP");
			batch.addElement("INDEX").addAttribute("FIELD", "BatchSeqNo").setText("999999");
			batch.addElement("INDEX").addAttribute("FIELD", "Branch").setText("98");
			batch.addElement("INDEX").addAttribute("FIELD", "ReceivedDate").setText(currentDate);
			batch.addElement("INDEX").addAttribute("FIELD", "LFCM").setText(currentDate);
			batch.addElement("INDEX").addAttribute("FIELD", "ProcessType").setText("RUNI");
			batch.addElement("INDEX").addAttribute("FIELD", "BatchCycle").setText(currentDate);
			
			Element folder = batch.addElement("FOLDER").addAttribute("NAME", policyNoFolder).addAttribute("CLASS", "FLD_UNI04");
			
			folder.addElement("INDEX").addAttribute("FIELD", "FatherPolicyNo").setText(policyNo);
			folder.addElement("INDEX").addAttribute("FIELD", "SonPolicyNo").setText("");
			folder.addElement("INDEX").addAttribute("FIELD", "AgentCode1").setText("83587");
			folder.addElement("INDEX").addAttribute("FIELD", "AgentCode2").setText("");
			folder.addElement("INDEX").addAttribute("FIELD", "ClaimAmount").setText("0");
			folder.addElement("INDEX").addAttribute("FIELD", "OriginalDomain").setText("KLIW");
			folder.addElement("INDEX").addAttribute("FIELD", "Rescan").setText("N");
			folder.addElement("INDEX").addAttribute("FIELD", "Signature").setText("Y");
			folder.addElement("INDEX").addAttribute("FIELD", "MedCode").setText("0");
			folder.addElement("INDEX").addAttribute("FIELD", "ExpirationDays").setText("0");
			folder.addElement("INDEX").addAttribute("FIELD", "Magnum").setText("N");
			folder.addElement("INDEX").addAttribute("FIELD", "BoxNo").setText("EAPP-IMP");
			folder.addElement("INDEX").addAttribute("FIELD", "BatchSeqNo").setText("999999");
			folder.addElement("INDEX").addAttribute("FIELD", "Branch").setText("98");
			folder.addElement("INDEX").addAttribute("FIELD", "ReceivedDate").setText(currentDate);
			folder.addElement("INDEX").addAttribute("FIELD", "LFCM").setText(currentDate);
			folder.addElement("INDEX").addAttribute("FIELD", "ProcessType").setText("RUNI");
			folder.addElement("INDEX").addAttribute("FIELD", "BatchCycle").setText(currentDate);
			
			// Contract PDF
			Element docEle = folder.addElement("DOC").addAttribute("NAME", policyNoPDF)
					.addAttribute("CLASS", "DOC_UNI05").addAttribute("REFER", "");
			
			List<String> pageNames = new ArrayList<String>();
			pageNames.add(fullPDFName);
			
			generateDocElement(docEle, "V1706155", "Fil", currentDate, pageNames, policyNo);
			
			// APF TIFF
			docEle = folder.addElement("DOC").addAttribute("NAME", policyNoTIF)
					.addAttribute("CLASS", "DOC_UNI05").addAttribute("REFER", "");
			
			generateDocElement(docEle, "V1706155", "No", currentDate, conTiffNames, policyNo);
			
			folder.addElement("INDEX").addAttribute("FIELD", "eSubmission").setText("Y");
			
			// Pretty print the document to baos
	        OutputFormat format = OutputFormat.createPrettyPrint();
	        XMLWriter writer = new XMLWriter(xmlBaos, format);
	        writer.write(doc);
	        writer.flush();
			
			//System.out.println("xml: " + doc.asXML().replaceAll("\n", ""));
			//doc.asXML().toString().getBytes();
			
		} catch(Exception ex) {
			System.out.println("[UploadWF.processXMLforPFV] Exception: " + ex.toString());
			ex.printStackTrace();
		}
		
		return xmlBaos;
	}

	private void generateDocElement(Element element, String formId, String voidStr, String currentDate, 
			List<String> pageNames, String policyNo) {
		element.addElement("INDEX").addAttribute("FIELD", "FatherPolicyNo").setText(policyNo);
		element.addElement("INDEX").addAttribute("FIELD", "SonPolicyNo").setText("");
		element.addElement("INDEX").addAttribute("FIELD", "FormID").setText(formId);
		element.addElement("INDEX").addAttribute("FIELD", "Void").setText(voidStr);
		element.addElement("INDEX").addAttribute("FIELD", "Verified").setText("N");
		element.addElement("INDEX").addAttribute("FIELD", "AgentCode1").setText("83587");
		element.addElement("INDEX").addAttribute("FIELD", "AgentCode2").setText("");
		element.addElement("INDEX").addAttribute("FIELD", "MedCode").setText("0");
		element.addElement("INDEX").addAttribute("FIELD", "BoxNo").setText("EAPP-IMP");
		element.addElement("INDEX").addAttribute("FIELD", "BatchSeqNo").setText("999999");
		element.addElement("INDEX").addAttribute("FIELD", "Branch").setText("98");
		element.addElement("INDEX").addAttribute("FIELD", "ReceivedDate").setText(currentDate);
		element.addElement("INDEX").addAttribute("FIELD", "LFCM").setText(currentDate);
		element.addElement("INDEX").addAttribute("FIELD", "ProcessType").setText("RUNI");
		element.addElement("INDEX").addAttribute("FIELD", "BatchCycle").setText(currentDate);
		
		for(String pageName: pageNames) {
			element.addElement("PAGE").setText(pageName);
		}
	}
}