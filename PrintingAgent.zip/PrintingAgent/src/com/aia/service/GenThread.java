package com.aia.service;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import com.aia.common.db.DBCommon;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.pdfGenerator.util.GenericUtil;

public class GenThread extends Thread {
	List<String> taxInvNoProcessList = null;
	HashMap<Integer, HashMap<String, String>> taxInvRSAll = null;
	String processYear = null;
	String uniqueID = null;
	int summSeqNo = 0;
	int fileSeqNo = 0;
	String fileName = null;
	String sourceSystem = null;
	CountDownLatch waitCount = null;
	String inputType = null;
	
	public GenThread(List<String> taxInvNoProcessList, HashMap<Integer, HashMap<String, String>> taxInvRSAll, 
			String processYear, String uniqueID, int summSeqNo, int fileSeqNo, String fileName, String sourceSystem, 
			CountDownLatch waitCount, String inputType) {
		super();
		this.taxInvNoProcessList = taxInvNoProcessList;
		this.taxInvRSAll = taxInvRSAll;
		this.processYear = processYear;
		this.uniqueID = uniqueID;
		this.summSeqNo = summSeqNo;
		this.fileSeqNo = fileSeqNo;
		this.fileName = fileName;
		this.sourceSystem = sourceSystem;
		this.waitCount = waitCount;
		this.inputType = inputType;
	}
	
	public void run() {
		long threadID = Thread.currentThread().getId();
		genPDFBatchThread(threadID);
		
		waitCount.countDown();
	}
	
	public void genPDFBatchThread(long threadID) {
		
		List<String> taxInvNoList = taxInvNoProcessList;

		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GenericUtil gu = new GenericUtil();
		
		GeneratePDF gp = new GeneratePDF();
		
		boolean isOriginal = false;
		String sourceType = "";
		
		List<ByteArrayOutputStream> masterBaos = new ArrayList<ByteArrayOutputStream>();
		List<List<String>> taxInvListPerBaos = new ArrayList<List<String>>();  
		List<String> taxInvPrintedList = new ArrayList<String>();
		
		ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
		
		int currTaxInvPerFile = 0;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss:SSS");
		
		try {
			for(String taxInvNo : taxInvNoList) {
				ByteArrayOutputStream tempPDFBaos = new ByteArrayOutputStream();
				
				HashMap<Integer, HashMap<String, String>> taxInvRS = new HashMap<Integer, HashMap<String,String>>();
				
				int currIdx = 0;
				
				for (int i=0; i<taxInvRSAll.size(); i++) {
					HashMap<String, String> singleTaxInvRS = taxInvRSAll.get(i);
					if (taxInvNo.equalsIgnoreCase(singleTaxInvRS.get("TaxInvoiceNo"))) {
						taxInvRS.put(currIdx, taxInvRSAll.get(i));
						currIdx ++;
						singleTaxInvRS.remove(i);
					}
				}
				
				//-------------------------------------------START CALCULATE TOTAL------------------------------------------- 
				Double totalIncGST = 0.0;
				Double totalGST = 0.0;
				Double totalExcGST = 0.0;
				
				for (int i=0; i<taxInvRS.size(); i++) {
					HashMap<String, String> taxRowRec = taxInvRS.get(i);
					
					totalExcGST += Double.parseDouble(taxRowRec.get("AmtExclGST"));
					totalGST += Double.parseDouble(taxRowRec.get("AmtGST"));
					totalIncGST += Double.parseDouble(taxRowRec.get("AMTInclGST"));
				}
				
				for(int i=0; i<taxInvRS.size(); i++) {
					HashMap<String, String> rowData = taxInvRS.get(i);
		        	rowData.put("totalIncGST", String.valueOf(totalIncGST));
		        	rowData.put("totalGST", String.valueOf(totalGST));
		        	rowData.put("totalExcGST", String.valueOf(totalExcGST));
		        }						
				//-------------------------------------------END CALCULATE TOTAL-------------------------------------------
										
				HashMap<String, String> taxInvMaster = taxInvRS.get(0);
				
				String docFormat = dc.getDocFormat(taxInvMaster);
				sourceType = taxInvMaster.get("SourceType");
				
				// check for 8 characters policy number and convert to 10 characters
				taxInvRS = dc.checkAndConvertTo10CharPolNo(sourceType, taxInvRS);
				
				isOriginal = gp.validateIsOriginalCopy(inputType, docFormat, taxInvMaster);
				
				if (docFormat != null && docFormat.trim().length() > 0) {
					boolean isGen = true;
					
					if("B".equals(inputType)) {
						if (!cu.getHardCopy().equals(docFormat)) {
							isGen = false;
						}
					}
					
					if (isGen) {
						HashMap<Integer, HashMap<String, String>> gstSummary = gp.getGSTSummary(taxInvRS);
						taxInvPrintedList.add(taxInvNo);
						
						if (currTaxInvPerFile%10 == 0) {
							System.out.println("[" + sdf.format(new java.util.Date()) + "][" + currTaxInvPerFile + "] [" + threadID + "] Records Done!!!");
						}
						
						if (cu.getCreditNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = gp.genCreditNote(taxInvRS, gstSummary);									
						} else if (cu.getDebitNote().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = gp.genDebitNote(taxInvRS, gstSummary);
						} else if (cu.getSelfBill().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = gp.genSelfBill(taxInvRS);
						} else if (cu.getTaxInvoice().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = gp.genTaxInvoice(taxInvRS, gstSummary);
						} else if (cu.getSelfBill_claim().equalsIgnoreCase(taxInvMaster.get("DocType"))) {
							tempPDFBaos = gp.genSelfBillClaim(taxInvRS);
						}
						
						if (!isOriginal) {
							tempPDFBaos = gu.addWaterMark(tempPDFBaos);
						}
						
						currTaxInvPerFile++;
					}
				}
				
				if (tempPDFBaos != null && tempPDFBaos.toByteArray().length > 0) {
					pdfBaos = gu.mergePDF(pdfBaos, tempPDFBaos);
				}
				
				if (currTaxInvPerFile == cu.getMaxTaxInvPerFile()) {
					if ("B".equalsIgnoreCase(inputType)) {
						pdfBaos = gu.addOMRnIntNo(pdfBaos);
					}
					
					masterBaos.add(pdfBaos);
					pdfBaos = new ByteArrayOutputStream();
					currTaxInvPerFile = 0;
					
					taxInvListPerBaos.add(taxInvPrintedList);
					
					dc.updateWorkableProcess(processYear, "Y", taxInvPrintedList);
					
					taxInvPrintedList = new ArrayList<String>();
				}
			}
			
			if (currTaxInvPerFile > 0) {
				if ("B".equalsIgnoreCase(inputType)) {
					pdfBaos = gu.addOMRnIntNo(pdfBaos);
				}
				
				masterBaos.add(pdfBaos);
				pdfBaos = new ByteArrayOutputStream();
				currTaxInvPerFile = 0;
				
				taxInvListPerBaos.add(taxInvPrintedList);
				
				dc.updateWorkableProcess(processYear, "Y", taxInvPrintedList);
				
				taxInvPrintedList = new ArrayList<String>();
			}
		
			for (int baosNo = 0; baosNo < masterBaos.size(); baosNo++) {
				//-------------------------------------------- Generate Summary Page Start --------------------------------------------
				if ("B".equalsIgnoreCase(inputType)) {
					ByteArrayOutputStream pdfWithSumm = gp.genSummaryPage(uniqueID, masterBaos.get(baosNo), baosNo, taxInvListPerBaos, sourceType);
					
					pdfWithSumm = gu.mergePDF(pdfWithSumm, masterBaos.get(baosNo));
					
					masterBaos.set(baosNo, pdfWithSumm);
				}
				//-------------------------------------------- Generate Summary Page End --------------------------------------------
				
				if ("B".equalsIgnoreCase(inputType)) {
					dc.addToImgDB(uniqueID, summSeqNo, fileSeqNo, masterBaos.get(baosNo), "Y", "N", sourceType, inputType, fileName);
					
				} else if ("R".equalsIgnoreCase(inputType) || "A".equalsIgnoreCase(inputType)) {
					dc.addToImgDB(uniqueID, summSeqNo, fileSeqNo, masterBaos.get(baosNo), "N", "R", sourceType, inputType);
				}
				
				dc.addPrintSummDet(uniqueID, summSeqNo, fileSeqNo, uniqueID + "_" + fileSeqNo, sourceSystem);
			}
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] [GenThread.java] genPDFBatchThread() generate PDF File END --------------------------------");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}