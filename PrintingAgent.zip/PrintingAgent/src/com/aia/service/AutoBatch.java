package com.aia.service;

import java.util.HashMap;
import java.util.List;

import com.aia.common.db.DBCommon;
import com.aia.common.model.ClaimsData;
import com.aia.common.model.NBAgentContact;
import com.aia.common.model.Notification;
import com.aia.common.model.POSServiceRequest;
import com.aia.common.model.PolWebForm;
import com.aia.common.model.PolicyInfo;
import com.aia.pdfGenerator.util.CommonFileUtil;

public class AutoBatch extends Thread {
	private Thread t;
	private String threadName;
	
	public AutoBatch(String name) {
		this.threadName = name;
		System.out.println("Creating thread " +  threadName + "...");
	}
	
	public void run() {
		System.out.println("Running thread " +  threadName + "...");
		
		DBCommon db = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		HashMap<String, String> configs = new HashMap<String, String>();
		String template = null;
		
		try {
			// execute batch
			while(true) {
				configs = db.getSystemConfig();
				
				int recoverTime = Integer.parseInt(configs.get("BatchCheckTime"));
				boolean checkBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnableBatch"))? true: false;
				boolean webFormCheckBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnableWebBatch"))? true: false;
				boolean agentCheckBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnableAgentBatch"))? true: false;
				
				int mobileRecoverTime = Integer.parseInt(configs.get("MobileBatchCheckTime"));
				boolean mobileCheckBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnableMobileBatch"))? true: false;
				
				int posRecoverTime = Integer.parseInt(configs.get("POSBatchCheckTime"));
				boolean mobilePOSBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnablePOSBatch"))? true: false;
				
				int nbRecoverTime = Integer.parseInt(configs.get("NBBatchCheckTime"));
				boolean mobileNBBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnableNBBatch"))? true: false;
				
				int claimRecoverTime = Integer.parseInt(configs.get("ClaimBatchCheckTime"));
				boolean mobileClaimBatch = cu.getEnable().equalsIgnoreCase(configs.get("EnableClaimBatch"))? true: false;
				
				if("BatchCheck".equals(this.threadName)) {
					if(checkBatch) {
						List<PolicyInfo> policyInfos = db.getPolicyListToPrint("NEW");
						
						// process each policy
						for(PolicyInfo policyInfo: policyInfos) {
							HashMap<Integer, HashMap<String, String>> covInfoMap = db.getPolCoverage(
									policyInfo.getCompanyCode(), policyInfo.getPolicyNo());
							
							if(covInfoMap.size() > 0) {
								for(int i = 0; i < covInfoMap.size(); i++) {
									HashMap<String, String> row = covInfoMap.get(i);
									
									System.out.println("ProcessBatch (Plan Code): "+ row.get("PlanCode"));
									template = db.getTemplate(policyInfo.getCompanyCode(), row.get("PlanCode"));
									
									if(!cu.isBlank(template)) break;
								}
							}
							
							System.out.println("Template from table: " + template);
							ProcessBatch batch = new ProcessBatch(policyInfo, template);
							batch.execute();
						}
					}
					
					Thread.sleep(recoverTime * 1000);
				}
				
				if("WebFormBatchCheck".equals(this.threadName)) {
					if(webFormCheckBatch) {
						List<PolWebForm> policyWebForms = db.getWebFormPolicyListToPrint("New");
						
						// process each policy
						for(PolWebForm policyWebForm: policyWebForms) {
							ProcessBatch batch = new ProcessBatch(policyWebForm, "TPL004");
							batch.executeWebForm();
						}
					}
					
					Thread.sleep(recoverTime * 1000);
				}
				
				if("AgentBatchCheck".equals(this.threadName)) {
					if(agentCheckBatch) {
						// get list of trx id
						List<String> trxIds = db.getAgentTrxListToPrint("Pending");
						
						// process each agent trx_id
						for(String trxId: trxIds) {
							ProcessBatch batch = new ProcessBatch(trxId, "TPL005");
							batch.executeAgentForm();
						}
					}
					
					Thread.sleep(recoverTime * 1000);
				}
				
				if("MobileBatch".equals(this.threadName)) {
					if(mobileCheckBatch) {
						List<Notification> notifications = db.getNotificationList("NEW", "FAILED");
						
						for(Notification n: notifications) {
							System.out.println("Process notification: " + n.getGuid() + ", " + n.getNotificationType() + 
									", " + n.getAgentCode() + ", " + n.getPolicyNumber());
							
							MobileBatch batch = new MobileBatch(n, null, null, null);
							batch.execute();
						}
					}
					
					Thread.sleep(mobileRecoverTime * 1000);
				}
				
				if("POSBatch".equals(this.threadName)) {
					if(mobilePOSBatch) {
						List<POSServiceRequest> posServiceRequests = db.getPOSServiceRequestList("NEW", "FAILED");
						
						for(POSServiceRequest sr: posServiceRequests) {
							System.out.println("Process POS service request: " + sr.getPolicyNo() + ", " + 
									sr.getKeyRequestNo() + ", " + sr.getSubmitAgentCode() + ", " + sr.getReqStatus());
							
							MobileBatch batch = new MobileBatch(null, sr, null, null);
							batch.execute();
						}
					}
					
					Thread.sleep(posRecoverTime * 1000);
				}
				
				if("NBBatch".equals(this.threadName)) {
					if(mobileNBBatch) {
						List<NBAgentContact> agentContacts = db.getNBAgentContactList("NEW", "FAILED");
						
						for(NBAgentContact ac: agentContacts) {
							System.out.println("Process NB agent contact: " + ac.getAgentNo() + ", " + 
									ac.getOwnerName() + ", " + ac.getOwnerIcNo() + ", " + ac.getLineOfBusiness());
							
							MobileBatch batch = new MobileBatch(null, null, ac, null);
							batch.execute();
						}
					}
					
					Thread.sleep(nbRecoverTime * 1000);
				}
				
				if("ClaimBatch".equals(this.threadName)) {
					if(mobileClaimBatch) {
						List<ClaimsData> claimsList = db.getClaimsDataList("NEW", "FAILED");
						
						for(ClaimsData cl: claimsList) {
							System.out.println("Process claims data: " + cl.getClaimNo() + ", " + 
									cl.getOccurrence() + ", " + cl.getAgentNo() + ", " + cl.getInsuredPerson());
							
							MobileBatch batch = new MobileBatch(null, null, null, cl);
							batch.execute();
						}
					}
					
					Thread.sleep(claimRecoverTime * 1000);
				}
			}
		} catch (InterruptedException e) {
			System.out.println("Thread " +  threadName + " interrupted.");
			
		} catch (Exception e) {
			System.out.println("Thread " +  threadName + " got exception.");
			e.printStackTrace();
		}
		
		System.out.println("Thread " +  threadName + " stopped.");
	}
	
	public void startBatch() {
		System.out.println("Starting thread " +  threadName + "...");
		
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}
}