package com.aia.service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import com.aia.common.db.DBCommon;
import com.aia.pdfGenerator.util.CommonFileUtil;
import com.aia.utility.DataLoader;

@WebService
public class PrintingAgentMain {
	private static Logger logger = Logger.getLogger(PrintingAgentMain.class);
	
	static {
		logger.info("Starting PrintingAgent web wervice...");
		
		try {
			DataLoader.loadData();
			DataLoader.resetUBPData();
			DataLoader.resetTaxInvImg();
			
			AutoBatch ab = new AutoBatch("BatchCheck");
			ab.startBatch();
			
			AutoBatch wfab = new AutoBatch("WebFormBatchCheck");
			wfab.startBatch();
			
			AutoBatch abc = new AutoBatch("AgentBatchCheck");
			abc.startBatch();
			
			AutoBatch mobileBatch = new AutoBatch("MobileBatch");
			mobileBatch.startBatch();
			
			AutoBatch mobilePOSBatch = new AutoBatch("POSBatch");
			mobilePOSBatch.startBatch();
			
			AutoBatch mobileNBBatch = new AutoBatch("NBBatch");
			mobileNBBatch.startBatch();
			
			AutoBatch mobileClaimBatch = new AutoBatch("ClaimBatch");
			mobileClaimBatch.startBatch();
			
			CoverLetter cl = new CoverLetter();
			cl.startBatch();
			
			BillingStatement bs = new BillingStatement();
			bs.startBatch();
			
			MasterBilling mb = new MasterBilling();
			mb.startBatch();
			
			DebitNote dn = new DebitNote();
			dn.startBatch();
			
			jcifs.Config.setProperty("jcifs.smb.client.disablePlainTextPasswords", "false");
			jcifs.Config.setProperty("jcifs.resolveOrder", "DNS");
			jcifs.Config.setProperty("jcifs.smb.client.dfs.disabled", "false");
			jcifs.Config.setProperty("jcifs.util.loglevel", "3");
			
		} catch (Exception e) {
			logger.error("Can't start web service auto batch.", e);
		}
		
		logger.info("PrintingAgent web service started.");
	}
	
	@WebMethod(action = "gstTaxInvPrint")
	@WebResult(name = "gstTaxInvPrint")
	public String gstTaxInvPrint ( 
			@WebParam(name = "invoiceNo") String invoiceNo,
			@WebParam(name = "docType") String docType,
			@WebParam(name = "sourceSystem") String sourceSystem,
			@WebParam(name = "inputType") String inputType,
			@WebParam(name = "srcFileName") String srcFileName) {
		/* docType Code and Description
		 * CR = Credit Note
		 * DR = Debit Note
		 * SB = Self-billed Invoice
		 * TI = Tax Invoice
		 * RA = Agent Self-billed Invoice
		 * 
		 * sourceSystem (from which system)
		 * ALPP
		 * TB2C = Takaful Bill to Client
		 * GAMS
		 * 
		 * inputType 
		 * A = Adhoc
		 * B = Batch
		 * R = Regen
		*/
		
		System.out.println("-------------------------- [" + new java.util.Date() + "] [PrintingAgentMain.java] gstTaxInvPrint Start [" + invoiceNo + "][" + docType + "][" + sourceSystem + "][" + inputType + "][" + srcFileName + "]" + "--------------------------");
		
		String uniqueID = UUID.randomUUID().toString();
		
		if ("A".equalsIgnoreCase(inputType)) {
			uniqueID = invoiceNo;
			
			if("GAMS".equalsIgnoreCase(sourceSystem) || "GSTS".equalsIgnoreCase(sourceSystem) || "SSTS".equalsIgnoreCase(sourceSystem)) {
				uniqueID = adhocGen(uniqueID, docType, sourceSystem, inputType, srcFileName);
			} else {
				adhocGen(uniqueID, docType, sourceSystem, inputType, srcFileName);
			}
		} else if ("B".equalsIgnoreCase(inputType)) {
			batchGen(uniqueID, sourceSystem, inputType, srcFileName);
			
		} else if ("R".equalsIgnoreCase(inputType)) {
			uniqueID = invoiceNo;
			reGen(uniqueID, srcFileName);
			
		} else {
			System.out.println("--------------------------------[" + new java.util.Date() + "] [PrintingAgentMain.java] [gstTaxInvPrint] inputType = NULL --------------------------------");
			uniqueID = null;
		}
		
		System.out.println("-------------------------- [" + new java.util.Date() + "] [PrintingAgentMain.java] gstTaxInvPrint End [" + invoiceNo + "][" + docType + "][" + sourceSystem + "][" + inputType + "][" + srcFileName + "]" + "--------------------------");
		return uniqueID;
	}
	
	/*@WebMethod(action = "getPolicyImage")
	@WebResult(name = "getPolicyImage")
	public String getPolicyImage(
			@WebParam(name = "companyCode") String companyCode,
			@WebParam(name = "policyNo") String policyNo,
			@WebParam(name = "templateCode") String templateCode,
			@WebParam(name = "language") String language,
			@WebParam(name = "policyInfo") PolicyInfo policyInfo,
			@WebParam(name = "appForm") AppForm appForm) {
		
		System.out.println("-------------------------- [" + new java.util.Date() + "] [PrintingAgentMain] getPolicyImage Start [" + companyCode + "][" + policyNo + "][" + templateCode + "][" + language + "]--------------------------");
		
		String uniqueID = UUID.randomUUID().toString();
		
		uniqueID = policyGen(uniqueID, companyCode, policyNo, templateCode, language, policyInfo, appForm);
		
		System.out.println("-------------------------- [" + new java.util.Date() + "] [PrintingAgentMain] getPolicyImage End [" + companyCode + "][" + policyNo + "][" + templateCode + "][" + language + "]--------------------------");
		return uniqueID;
	}*/
	
	/*public String policyGen(String uniqueID, String companyCode, String policyNo, String templateCode, 
			String language, PolicyInfo policyInfo, AppForm appForm) {
		//TODO: check policy contents
		
		GeneratePDF gp = new GeneratePDF();
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		UploadWF uwf = new UploadWF();
		
		Map<String, ByteArrayOutputStream> pdfBaosMap = null;
		
		try {
			PolicyInfo policyInfoDb = dc.getPolicyDetails(companyCode, policyNo, cu.getPolCovType());
			AppForm appFormDb = null;
			
			// get app form
			if(!cu.isBlank(policyInfoDb))
				appFormDb = dc.getAppFormDetails(policyInfoDb.getPolicyId());
			
			if(policyInfoDb.getPolicyId() == null && policyInfo != null && appForm != null) {
				cu.addXMLData2ProcessTbl(uniqueID, policyInfo, appForm);
				
				policyInfoDb = dc.getPolicyDetails(companyCode, policyNo, cu.getPolCovType());
				appFormDb = dc.getAppFormDetails(policyInfoDb.getPolicyId());
			}
			
			// generate the pdf
			pdfBaosMap = gp.genPolicyPDF(policyInfoDb, appFormDb, templateCode, language);
						
			// upload to workflow
			uwf.upload(pdfBaosMap, companyCode, policyNo);
			
		} catch(Exception ex) {
			ex.printStackTrace();
			
		} finally {
			pdfBaosMap = null;
		}
		
		return policyNo;
	}*/

	private synchronized String adhocGen(String uniqueID, String docType, String sourceSystem, String inputType, String srcFileName) {
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GeneratePDF gp = new GeneratePDF();
		
		try {
			// return uniqueID if already exists in TBL_TAXINVIMG for ALPP to reduce process
			if("ALPP".equalsIgnoreCase(sourceSystem) && "A".equalsIgnoreCase(inputType)) {
				if(dc.isExistsInTaxInvImg(uniqueID)) return uniqueID;
			}
			
			String processYear = "";
			HashMap<Integer, HashMap<String, String>> taxInvDetails = new HashMap<Integer, HashMap<String,String>>();
			
			List<String> tableYears = dc.getTableYear();
			
			for (String tableYear: tableYears) {
				if (processYear == null || processYear.trim().length() == 0) {
					processYear = tableYear;
				}
				
				taxInvDetails = dc.getTaxInvDetails(uniqueID, tableYear);
				
				if (taxInvDetails != null && taxInvDetails.size() > 0) {
					if (!processYear.equals(tableYear)) {
						processYear = tableYear;
					}
					break;
				}
			}
			
			// check if from GAMS or GSTS, then if Indicator = U, delete from tbl_TaxInv_(Year) based on
			// tax invoice number and reinsert using new file
			// return error (PAG1, PAG2 and PAG3) if have any problems
			if("GAMS".equalsIgnoreCase(sourceSystem) || "GSTS".equalsIgnoreCase(sourceSystem) || "SSTS".equalsIgnoreCase(sourceSystem)) {
				List<String> processFileList = cu.getGAMSTXT(uniqueID, processYear, inputType, srcFileName);
				System.out.println("processFileList: " + processFileList.size() + ", taxDetails: " + taxInvDetails.size());
				
				if(processFileList.size() == 0 && taxInvDetails.size() == 0) return "PAG1";
				
				if(cu.getCsvAddIndicator().equals(cu.getCSVFileIndicator(uniqueID, processFileList))) {
					if(taxInvDetails != null && taxInvDetails.size() > 0) return "PAG2";
				}
				
				if(cu.getCsvUpdateIndicator().equals(cu.getCSVFileIndicator(uniqueID, processFileList))) {
					if(taxInvDetails.size() == 0) return "PAG3";
					
					dc.removeTaxInvEntry(uniqueID, processYear);
					taxInvDetails = dc.getTaxInvDetails(uniqueID, processYear);
				}
			}
			
			if (taxInvDetails == null || taxInvDetails.size() == 0) {
				List<String> processFileList = cu.getGAMSTXT(uniqueID, processYear, inputType, srcFileName);
				
				if (processFileList != null && processFileList.size() > 0) {
					for (int z=0; z<processFileList.size(); z++) {
						cu.archiveTXT(uniqueID, processFileList.get(z), z, inputType);
					}
				} else {
					System.out.println("--------------------------------[" + new java.util.Date() + "] [PrintingAgentMain.java] adhocGen() End!!! Unable copy file!!!--------------------------------");
					dc.updatePrintSummaryStatus(uniqueID, 0, "E", "Unable copy file");
					
					return null;
				}
				
				cu.AddData2ProcessTbl(uniqueID, processFileList, processYear);
				
				if("GAMS".equalsIgnoreCase(sourceSystem) || "GSTS".equalsIgnoreCase(sourceSystem) || "SSTS".equalsIgnoreCase(sourceSystem)) {
					taxInvDetails = dc.getTaxInvDetails(uniqueID, processYear);
					
					HashMap<String, String> masterTaxInvDet = taxInvDetails.get(0);
					 
					gp.genAdhocPDF(masterTaxInvDet.get("SummaryID"), uniqueID, taxInvDetails, inputType, processYear, sourceSystem);
					
				} else {
					gp.genBatchPDF(uniqueID, processFileList, processYear, inputType, sourceSystem);
				}
				
				cu.removeWorkingTXT(uniqueID);
				
			} else {
				HashMap<String, String> masterTaxInvDet = taxInvDetails.get(0);
				 
				gp.genAdhocPDF(masterTaxInvDet.get("SummaryID"), uniqueID, taxInvDetails, inputType, processYear, sourceSystem);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return uniqueID;
	}
	
	private void batchGen(String uniqueID, String sourceSystem, String inputFrom, String srcFileName) {
		System.out.println("--------------------------------[" + new java.util.Date() + "] [PrintingAgentMain.java] batchGen() Start --------------------------------");
		
		final String sourceFrom = sourceSystem;
		final String processID = uniqueID;
		final String inputType = inputFrom;
		final String fileName = srcFileName;
		
		DBCommon dc = new DBCommon();
		CommonFileUtil cu = new CommonFileUtil();
		GeneratePDF gp = new GeneratePDF();
		
		try {
			String processYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
			
			List<String> processFileList = cu.getGAMSTXT(processID, processYear, inputType, fileName);
			
			if (processFileList != null && processFileList.size() > 0) {
				for (int z=0; z<processFileList.size(); z++) {
					cu.archiveTXT(processID, processFileList.get(z), z, inputType);
				}
			} else {
				System.out.println("--------------------------------[" + new java.util.Date() + "] [PrintingAgentMain.java] batchGen() End!!! Unable copy file!!!--------------------------------");
				dc.updatePrintSummaryStatus(processID, 0, "E", "Unable copy file");
				return;
			}
			
			cu.AddData2ProcessTbl(processID, processFileList, processYear);
			
			gp.genBatchPDF (processID, processFileList, processYear, "B", sourceFrom);
			
			cu.removeWorkingTXT(processID);
			
			System.out.println("--------------------------------[" + new java.util.Date() + "] Generate PDF End--------------------------------");
		} catch(Exception ex){
            ex.printStackTrace();
        }
		
		System.out.println("--------------------------------[" + new java.util.Date() + "] [PrintingAgentMain.java] batchGen() End --------------------------------");		
	}
	
	private String reGen(String uniqueID, String seqNo) {
		GeneratePDF gp = new GeneratePDF();
		
		try {
			gp.reGen(uniqueID, seqNo);
			//gp.newReGen(uniqueID, seqNo);
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return uniqueID;
	}
}