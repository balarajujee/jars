package com.aia.utility;

import ho.aia.utility.database.DBConnect;

import java.sql.Connection;
import java.sql.SQLException;

public class DBUtil {
	public synchronized static Connection getConnection(String dbName) throws SQLException {
		DBConnect dbConnect = new DBConnect();
		
		if (isBlank(dbName)) {
			dbName = "nb";
		}
		
		return dbConnect.getConnection(dbName);
	}
	
	public static boolean isBlank(Object object) {
		if(object == null || "".equals(object.toString().trim()))
			return true;
		else
			return false;
	}
}