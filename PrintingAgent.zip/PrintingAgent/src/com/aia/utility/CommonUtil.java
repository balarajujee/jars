package com.aia.utility;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class CommonUtil {
	public static String decodeXSS(String id) throws Exception {
		String xss = "";
		
		try {
			int[] avarInt = new int[30];
			int inc = 48;
			int intk = 0;
			String strdec1 = "";
			String[] strdec = null;
			String temp = "";

			avarInt[0] = 14;
	        avarInt[1] = 20;
	        avarInt[2] = 10;
	        avarInt[3] = 16;
	        avarInt[4] = 4;
	        avarInt[5] = 8;
	        avarInt[6] = 31;
	        avarInt[7] = 7;
	        avarInt[8] = 9;
	        avarInt[9] = 12;
	        avarInt[10] = 11;
	        avarInt[11] = 2;
	        avarInt[12] = 7;
	        avarInt[13] = 1;
	        avarInt[14] = 9;
	        avarInt[15] = 2;
	        avarInt[16] = 7;
	        avarInt[17] = 3;
	        avarInt[18] = 16;
	        avarInt[19] = 27;
	        avarInt[20] = 8;
	        avarInt[21] = 5;
	        avarInt[22] = 18;
	        avarInt[23] = 11;
	        avarInt[24] = 2;
	        avarInt[25] = 8;
	        avarInt[26] = 9;
	        avarInt[27] = 3;
	        avarInt[28] = 5;
	        avarInt[29] = 27;

	        strdec1 = id.substring(1, id.length());
	        strdec = strdec1.split("-");
	        int size = strdec.length;
	        
	        for(int i = 0; i < size; i++) {
	        	if (i < 29) {
	        		intk = i % 30;
	        		
	        	} else {
	        		intk = i;
	        	}
	        	
	        	temp = temp + (char)(Integer.parseInt(strdec[i]) - inc - avarInt[intk]);
	        }
	        
	        xss = temp;

		} catch (Exception ex) {
			System.out.println("Exception decodeXSS: " + ex);
		}
		
		return xss;
	}
	
	public static boolean isBlank(Object object) {
		if(object == null || "".equals(object.toString().trim()))
			return true;
		else
			return false;
	}
	
	public static ResourceBundle getResourceBundle(String bundleName) {
		return getResourceBundle(null, null, bundleName);
	}
	
	public static ResourceBundle getResourceBundle(String language, String country, String bundleName) 
			throws MissingResourceException {
		Locale locale = null;
		
		if(isBlank(bundleName)) bundleName = "messages";
		
		if(!isBlank(language) && !isBlank(country))
			locale = new Locale(language, country);
		
		else if(!isBlank(language))
			locale = new Locale(language);
		
		else
			locale = Locale.getDefault();
		
		ResourceBundle rb = null;
		
		rb = ResourceBundle.getBundle(bundleName, locale);
		
		return rb;
	}
	
	public static String getMoneyFormat(BigDecimal value, int scale) {
		value = value.setScale(scale, BigDecimal.ROUND_UP);
		
		DecimalFormat df = new DecimalFormat();

		//df.setMaximumFractionDigits(scale);
		//df.setMinimumFractionDigits(0);

		df.setGroupingUsed(true);
		
		return df.format(value);
	}
}