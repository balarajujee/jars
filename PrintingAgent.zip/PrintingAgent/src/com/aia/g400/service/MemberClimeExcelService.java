package com.aia.g400.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.aia.g400.model.MemberClimeDetails;
import com.aia.g400.utility.MemberClimeExcelUtil;

public class MemberClimeExcelService extends Thread {
	private Thread t;
	
	public void run() {
		List<MemberClimeDetails> listmemberClimeDetails=getMemberClimeDetails();
		String excelFilePath ="F:\\Test_Read\\txtFiles\\MemberclimeDetailsExcel.xls";
		
		 MemberClimeExcelUtil.createExcel(listmemberClimeDetails, excelFilePath);
		
	             /*for(MemberClimeDetails memberClimeDetails:listmemberClimeDetails) {
	            	 System.out.println(memberClimeDetails);
	            	 
	            	
	             }*/
	}

	
	
	
/*public static List<MemberClimeDetails>	getMemberClimeDetails(){
	List<MemberClimeDetails> listmemberClimeDetails = new ArrayList<MemberClimeDetails>();
	
	  String csvFile = "D:\\Test_Read\\txtFiles\\MemberclaimDetailsExcel.txt";
      BufferedReader br = null;
      String line;
      String cvsSplitBy = "\\|";
int countRowlines=0;
      try {
          br = new BufferedReader(new FileReader(csvFile));
          while ((line = br.readLine()) != null) {
        	  
             String[] data = line.split(cvsSplitBy);
             MemberClimeDetails ClimeDetails=createMemberClimeDetails(data);
             listmemberClimeDetails.add(ClimeDetails);
            
             countRowlines++;
          }
          System.out.println("rows No : "+countRowlines);
      } catch (FileNotFoundException e) {
          e.printStackTrace();
      } catch (IOException e) {
          e.printStackTrace();
      } finally {
          if (br != null) {
              try {
                  br.close();
              } catch (IOException e) {
                  e.printStackTrace();
              }
          }
      }
	return listmemberClimeDetails;
	
  }*/
	
	public static List<MemberClimeDetails>	getMemberClimeDetails(){
		List<MemberClimeDetails> listmemberClimeDetails = new ArrayList<MemberClimeDetails>();
		
		 String filerReadPath = "F:\\Test_Read\\txtFiles\\MemberclimeDetailsExcel.txt";
		 BufferedReader br = null;
			 FileReader fr = null;
		
		try {
			fr=new FileReader(filerReadPath);
			br=new BufferedReader(fr);
			
		if(br==null || br.equals(null)) {
			System.out.println("No Debit Flat File....");
		}else {
			String sCurrentline;
			int currentLint=0;
			while((sCurrentline=br.readLine())!=null) {
				//System.out.println(sCurrentline);
				
				MemberClimeDetails memberClimeDetails=new MemberClimeDetails();
				
			    String data[]=sCurrentline.split("\\|");
				 for(int i=0; i<data.length;i++) {
					 if(!data[0].equalsIgnoreCase("POLICY NUMBER")) {
						 if(i==0) {
							 memberClimeDetails.setPolicyNum(data[0]);
						  }
						 if(i==1) {
							  memberClimeDetails.setCompanyName(data[i]);
						  }
						 if(i==2) {
							 memberClimeDetails.setBillingMonth(data[i]);
						  }
						 if(i==3) {
							    memberClimeDetails.setBillNum(data[i]);
						  }
						 if(i==4) {
							    memberClimeDetails.setClaimNum(data[i]);
						  }
						 if(i==5) {
							    memberClimeDetails.setEmpName(data[i]);
						  }
						 if(i==6) {
							    memberClimeDetails.setEmpIcOrPsprtNUm(data[i]);
						  }
						 if(i==7) {
							    memberClimeDetails.setEmpId(data[i]);
						  }
						 if(i==8) {
							    memberClimeDetails.setClaimantName(data[i]);
						  }
						 if(i==9) {
							    memberClimeDetails.setMembersh(data[i]);
						  }
						 if(i==10) {
							  
							    memberClimeDetails.setRelationShip(data[i]);
						  }
						 if(i==11) { 
							 memberClimeDetails.setPlanNum(data[i]);
						   }
						 if(i==12) {
							 memberClimeDetails.setPlandescr(data[i]);
							   
							   }
						 if(i==13) {
							 memberClimeDetails.setProdCode(data[i]);
							    
						  }
						 if(i==14) {
							 memberClimeDetails.setProdDescr(data[i]);
						}
						 if(i==15) {
							 memberClimeDetails.setBranch(data[i]);
							}
						 if(i==16) {
							 memberClimeDetails.setCostCentre(data[i]);
						}
						 if(i==17) {
							 memberClimeDetails.setVisitDate(data[i]);
							    
						  }
						 if(i==18) {
							 memberClimeDetails.setProvider(data[i]);
							}
						 if(i==19) {
							 memberClimeDetails.setClaimeType(data[i]);
							    
						  }
						 if(i==20) {
							 memberClimeDetails.setAsoBillAmt(data[i]);
						  }
						 if(i==21) {

							    memberClimeDetails.setAsoclaimsPaid(data[i]);
							    
						  }
						 if(i==22) {
							 memberClimeDetails.setClaimPaid(data[i]);
						  }
						 
					 }
					   
	                 
		    	}
				
					 listmemberClimeDetails.add(memberClimeDetails);
			
				  currentLint++;
				  
			}
			System.out.println("No of Rows : "+currentLint);
			
		}
			
		}catch(Exception e) {
			System.out.println("[memberClime.getMemberClimeDetails()]  Exception : "+e.toString());
		}
		
			return listmemberClimeDetails;
		}
	
/*private static MemberClimeDetails createMemberClimeDetails(String[] data) {
	MemberClimeDetails memberClimeDetails=new MemberClimeDetails();
	for(int i=0; i<data.length;i++) {
		memberClimeDetails.setPolicyNum(data[0]);
	    memberClimeDetails.setCompanyName(data[1]);
	    memberClimeDetails.setBillingMonth(data[2]);
	    memberClimeDetails.setBillNum(data[3]);
	    memberClimeDetails.setClaimNum(data[4]);
	    memberClimeDetails.setEmpName(data[5]);
	    memberClimeDetails.setEmpIcOrPsprtNUm(data[6]);
	    memberClimeDetails.setEmpId(data[7]);
	    memberClimeDetails.setClaimantName(data[8]);
	    memberClimeDetails.setMembersh(data[9]);
	    memberClimeDetails.setRelationShip(data[10]);
	    memberClimeDetails.setPlanNum(data[11]);
	    memberClimeDetails.setPlandescr(data[12]);
	    memberClimeDetails.setProdCode(data[13]);
	    memberClimeDetails.setProdDescr(data[14]);
	    memberClimeDetails.setBranch(data[15]);
	    memberClimeDetails.setCostCentre(data[16]);
	    memberClimeDetails.setVisitDate(data[17]);
	    memberClimeDetails.setProvider(data[18]);
	    memberClimeDetails.setClimeType(data[19]);
	    memberClimeDetails.setAsoBillAmt(data[20]);
	    memberClimeDetails.setAsoclaimsPaid(data[21]);
	    memberClimeDetails.setClaimPaid(data[22]);
	}
  		  
    return memberClimeDetails;
}*/
	
	
	
	public void startBatch() {
		System.out.println("Starting thread ");
		
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}
 public static void main(String args[]) {
	 MemberClimeExcelService memberClimeExcelService=new MemberClimeExcelService();
	 memberClimeExcelService.startBatch();
	 System.out.println("startedd.....");
 }
	
	
}