package com.aia.g400.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import com.aia.g400.model.Invoice;

public class InvoiceService extends Thread {

	private Thread t;

	public void run() {
		InvoiceService.generatePdf();
	}

	public static void generatePdf() {
		HashMap<Integer, HashMap<Integer, HashMap<String, String>>> ListinvoiceRSdetails = getInvoicDetails();
		int noFiles = ListinvoiceRSdetails.size();

		Invoice invoice = null;
		for (int i = 0; i < noFiles; i++) {
			HashMap<Integer, HashMap<String, String>> invoiceRS = ListinvoiceRSdetails
					.get(i);
			System.out.println(invoiceRS);
			HashMap<String, String> data=new HashMap<String, String>();
			for (int a = 0; a <invoiceRS.size(); a++) {
				HashMap<String, String> details = invoiceRS.get(a);
				
				data.putAll(details);
				

			}
			System.out.println("Data  : "+data);
			List<Invoice> invoiceList = new ArrayList<Invoice>();
			invoice = new Invoice();
			invoice.setCompanyName(data.get("companyName"));

			invoice.setAddressLine1(data.get("addressLine1"));
			invoice.setAddressLine2(data.get("addressLine2"));
			invoice.setAddressLine2(data.get("addressLine3"));
			invoice.setAddressLine2(data.get("addressLine4"));
			invoice.setAddressLine2(data.get("addressLine5"));

			invoice.setBillNum(data.get("billNum"));
			invoice.setDateOfIssue(data.get("dateOfIssue"));
			invoice.setBillingPeriod(data.get("billingPeriod"));
			invoice.setPaymentDueDate(data.get("paymentDueDate"));

			invoice.setPolicyHolder(data.get("policyHolder"));
			invoice.setSubsidiary(data.get("subsidiary"));
			invoice.setPolicyNum(data.get("policyNum"));
			invoice.setPolicyPeriod(data.get("policyPeriod"));
			invoice.setPoNum(data.get("poNum"));

			invoice.setDescription(data.get("description"));
			invoice.setBillType(data.get("billType"));
			invoice.setAmountExSt(data.get("amountExSt"));
			invoice.setAmountSt(data.get("amountSt"));
			invoice.setAmountInclSt(data.get("amountInclSt"));

			invoice.setReasonOfbilling(data.get("reasonOfbilling"));
			invoice.setTotalAmountInclSt(data.get("totalAmountInclSt"));
			invoice.setTotalAmtSt(data.get("totalAmtSt"));
			invoice.setTotalAmtExSt(data.get("totalAmtExSt"));

			// System.out.println("Address 1 : "+invoice.getAddressLine1());
			invoiceList.add(invoice);
			// String FILEREAD = "F:\\Test_Read\\Jasper\\invoice.jrxml";
			String FILEREAD = "F:\\Test_Read\\Jasper\\invoice.jasper";

			String FILEWRITE = "F:\\Test_Read\\Jasper\\pdf\\"
					+ invoice.getBillNum() + "_" + invoice.getPolicyNum()
					+ "_invoice.pdf";
			genReport(invoiceList, FILEREAD, FILEWRITE);

		}

	}

	public static void genReport(List<Invoice> invoiceList,
			String jrxmlReadPath, String pdfWritePath) {
		try {

			JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(
					invoiceList);

			// String FILEREAD = "F:\\Test_Read\\Jasper\\reportTest.jasper";
			// String FILEREAD = "F:\\Test_Read\\Jasper\\reportTest.jrxml";
			// String FILEWRITE = "F:\\Test_Read\\Jasper\\reportTest.pdf";

			// InputStream inputStream =
			// this.getClass().getResourceAsStream("/report.jasper");
			FileInputStream inputStream = new FileInputStream(jrxmlReadPath);
			// JasperReport jasperReport =
			// JasperCompileManager.compileReport(inputStream);

			JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream,
					null, dataSource);// for compiled Report .jasper file
			// JasperPrint jasperPrint =
			// JasperFillManager.fillReport(jasperReport, null, dataSource);//
			// for Report .jrxml file
			// JasperPrint jasperPrint =
			// JasperFillManager.fillReport(jasperReport, dataSource); //for Map

			FileOutputStream outputStream = new FileOutputStream(pdfWritePath);

			JasperExportManager.exportReportToPdfStream(jasperPrint,
					outputStream);
		} catch (Exception e) {
			System.out.println("Exception occurred : " + e);
		} finally {

		}
	}

	public static HashMap<Integer, HashMap<Integer, HashMap<String, String>>> getInvoicDetails() {
		String FILENAME = "F:\\Test_Read\\txtFiles\\invoice.txt";

		BufferedReader br = null;
		FileReader fr = null;
		HashMap<Integer, HashMap<String, String>> invoicresult = new HashMap<Integer, HashMap<String, String>>();
		HashMap<Integer, HashMap<Integer, HashMap<String, String>>> listInvoiceDetails = new HashMap<Integer, HashMap<Integer, HashMap<String, String>>>();

		try {
			fr = new FileReader(FILENAME);
			br = new BufferedReader(fr);
			if (br == null || br.equals("")) {
				System.out.println("No Invoice Flat file ");
			} else {
				String sCurrentLine;
				int cuurline = 0, pdfgencount = 0;

				while ((sCurrentLine = br.readLine()) != null) {
					// System.out.println("getInvoiceDetails() : sCurrentLine "+sCurrentLine);

					Boolean add = false;

					HashMap<String, String> invoice = new HashMap<String, String>();

					if (cuurline == 0 || sCurrentLine.contains("****")) {
						invoice = new HashMap<String, String>();
						invoicresult = new HashMap<Integer, HashMap<String, String>>();

						if (sCurrentLine.contains("****")) {
							pdfgencount++;
						}
						cuurline = 0;
					}
					String[] data = sCurrentLine.split("\\|");
					for (int i = 0; i < data.length; i++) {

						if (data[0].equalsIgnoreCase("0001")) {
							add = true;
						} // System.out.println(data[i]);

						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("01") && i == 3) {
							invoice.put("companyName", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
							// System.out.println(data[i] != null &&
							// data[i].length()>0 ?data[i].trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("01") && i == 4) {
							invoice.put("addressLine1", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
							// System.out.println(data[i] != null &&
							// data[i].length()>0 ?data[i].trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("01") && i == 5) {
							invoice.put("addressLine2", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
							// System.out.println(data[i] != null &&
							// data[i].length()>0 ?data[i].trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("01") && i == 6) {
							invoice.put("addressLine3", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("01") && i == 7) {
							invoice.put("addressLine4", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("01") && i == 8) {
							invoice.put("addressLine5", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}

						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("02") && i == 3) {
							invoice.put(
									"billNum",
									data[i] != null && data[i].length() > 0 ? data[i]
											.trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("02") && i == 4) {
							invoice.put("dateOfIssue", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("02") && i == 5) {
							invoice.put("billingPeriod", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("02") && i == 6) {
							invoice.put("paymentDueDate", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}

						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("03") && i == 3) {
							invoice.put("policyHolder", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("04") && i == 3) {
							invoice.put("subsidiary", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("05") && i == 3) {
							invoice.put(
									"policyNum",
									data[i] != null && data[i].length() > 0 ? data[i]
											.trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("06") && i == 3) {
							invoice.put("policyPeriod", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}

						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1H")
								&& data[2].equalsIgnoreCase("07") && i == 3) {
							invoice.put(
									"poNum",
									data[i] != null && data[i].length() > 0 ? data[i]
											.trim() : "");

						} /*
						 * if(data[0].equalsIgnoreCase("0001") &&
						 * data[1].equalsIgnoreCase("1D")
						 * &&data[2].equalsIgnoreCase("01")&& i == 3){
						 * invoice.put("sNo", data[i] != null &&
						 * data[i].length()>0 ?data[i].trim() : ""); }
						 */
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1D") && i == 4) {
							invoice.put("description", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1D")
								&& data[2].equalsIgnoreCase("01") && i == 5) {
							invoice.put(
									"billType",
									data[i] != null && data[i].length() > 0 ? data[i]
											.trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1D")
								&& data[2].equalsIgnoreCase("01") && i == 6) {
							invoice.put("amountExSt", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1D")
								&& data[2].equalsIgnoreCase("01") && i == 7) {
							invoice.put(
									"amountSt",
									data[i] != null && data[i].length() > 0 ? data[i]
											.trim() : "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1D")
								&& data[2].equalsIgnoreCase("01") && i == 8) {
							invoice.put("amountInclSt", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}

						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1T")
								&& data[2].equalsIgnoreCase("01") && i == 4) {
							invoice.put("totalAmtExSt", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1T")
								&& data[2].equalsIgnoreCase("01") && i == 5) {
							invoice.put("totalAmtSt", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1T")
								&& data[2].equalsIgnoreCase("01") && i == 6) {
							invoice.put("totalAmountInclSt", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1S")
								&& data[2].equalsIgnoreCase("01") && i == 3) {
							invoice.put("reasonOfbilling", data[i] != null
									&& data[i].length() > 0 ? data[i].trim()
									: "");
						}
						if (data[0].equalsIgnoreCase("0001")
								&& data[1].equalsIgnoreCase("1R")
								&& data[2].equalsIgnoreCase("01") && i == 3) {
							invoice.put(
									"email",
									data[i] != null && data[i].length() > 0 ? data[i]
											.trim() : "");
						}
					}
					if (add) {
						invoicresult.put(cuurline, invoice);
						cuurline++;
						// System.out.println("pdfgencount------> " +
						// pdfgencount);
						listInvoiceDetails.put(pdfgencount, invoicresult);
						// System.out.println("cuurline------> " + cuurline);
						// System.out.println("listInvoiceDetails inside------> "
						// + listInvoiceDetails);
					}
				}
				// System.out.println("---------------------------------------------------------------------");
				// System.out.println("[Total Generated PDF files:  "
				// +pdfgencount);
			}

		} catch (FileNotFoundException e) {
			System.out.println("[Invoice.getInvoicedetails] Exception: "
					+ e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listInvoiceDetails;
	}

	public void startBatch() {
		System.out.println("Starting thread ");

		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}

	public static void main(String args[]) {
		InvoiceService invoice = new InvoiceService();
		invoice.startBatch();
		System.out.println("startedd.....");
	}
}