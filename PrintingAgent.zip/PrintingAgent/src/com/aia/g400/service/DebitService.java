package com.aia.g400.service;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map.Entry;


public class DebitService extends Thread{

private Thread t;
	
	public void run() {
	
				DebitService.generatePdf();
			
		
	}
	
	
	
	
	private static void generatePdf() {
		// TODO Auto-generated method stub
		
		HashMap<Integer, HashMap<Integer, HashMap<String,  Object>>> listdebitRSdetails=getDebitDetails();
		int noFiles=listdebitRSdetails.size();
		int count=1;
		for(int i=0; i<noFiles;i++) {
			HashMap<Integer, HashMap<String, Object>> debitRS	=listdebitRSdetails.get(i);
			//System.out.println(invoiceRS);
			System.out.println("--------------------------------------------------------------File No : "+count++);
			
			for(int a=0;a<debitRS.size();a++) {
				HashMap<String, Object> details=debitRS.get(a);
				for(Entry<String, Object> entry:details.entrySet()) {
					System.out.println(entry.getKey()+"    =  "+entry.getValue());
				}
				
				
				/*
				 String FILEREAD = "D:\\TEST_Read\\invoice.jasper";
				String FILEWRITE = "D:\\TEST_Write\\report.pdf";
		    	
	           FileInputStream inputStream=new FileInputStream(FILEREAD);
				//JasperReport jasperReport = JasperCompileManager.compileReport(inputStream);
				
				JasperPrint jasperPrint = JasperFillManager.fillReport(inputStream, details);
				FileOutputStream outputStream=new FileOutputStream(FILEWRITE);
				
				JasperExportManager.exportReportToPdfStream(jasperPrint, outputStream);
			*/
				
				
			}
		}
		
	}
public static HashMap<Integer,HashMap<Integer, HashMap<String, Object>>>	getDebitDetails(){
	HashMap<Integer, HashMap<String, Object>> debitRS=new HashMap<Integer, HashMap<String, Object>>();
	HashMap<Integer,HashMap<Integer, HashMap<String, Object>>> listdebitRSdetails=new HashMap<Integer,HashMap<Integer, HashMap<String, Object>>>();
	 String filerReadPath = "F:\\Test_Read\\txtFiles\\Debit.txt";
	 BufferedReader br = null;
		 FileReader fr = null;
	
	try {
		fr=new FileReader(filerReadPath);
		br=new BufferedReader(fr);
		
	if(br==null || br.equals(null)) {
		System.out.println("No Debit Flat File....");
	}else {
		String sCurrentline;
		int currentLint=0, pdfGencount=0;
		while((sCurrentline=br.readLine())!=null) {
			//System.out.println(sCurrentline);
			Boolean add = false;
			HashMap<String, Object> debitdata=new HashMap<String, Object>();
			
			if(currentLint==0 || sCurrentline.contains("****")) {
				debitdata=new HashMap<String, Object>();
				debitRS=new HashMap<Integer, HashMap<String, Object>>();
				if(sCurrentline.contains("****")) {
					pdfGencount++;
				}
				currentLint=0;	
			}
			
		    String data[]=sCurrentline.split("\\|");
			 for(int i=0; i<data.length;i++) {
                 if(data[0].equalsIgnoreCase("0001")) {
                	 add=true;
                 }
                 if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==3) {
                	 debitdata.put("companyName", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==4) {
                	 debitdata.put("addressLine1", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==5) {
                	 debitdata.put("addressLine2", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==6) {
                	 debitdata.put("addressLine3", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==7) {
                	 debitdata.put("addressLine4", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==8) {
                	 debitdata.put("addressLine5", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("01") & i==9) {
                	 debitdata.put("addressLine6", data[i]!=null&& data[i].length()>0 ?data[i].trim() :"");
                 }
                    if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("02")&& i == 3){
						debitdata.put("billNum", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					} if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("02")&& i == 4){
						debitdata.put("dateOfIssue", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					} if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("02")&& i == 5){
						debitdata.put("billingPeriod", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					} if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") && data[2].equalsIgnoreCase("02")&& i == 6){
						debitdata.put("paymentDueDate", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
				    }
				
				    if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("03")&& i == 3){
						debitdata.put("policyHolder", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("04")&& i == 3){
						debitdata.put("subsidiary", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") &&data[2].equalsIgnoreCase("05")&& i == 3){
						debitdata.put("policyNum", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") && data[2].equalsIgnoreCase("06")&& i == 3){
						debitdata.put("policyPeriod", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 }
						
					 if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1H") && data[2].equalsIgnoreCase("07")&& i == 3){
						debitdata.put("poNum", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
						
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")  &&data[2].equalsIgnoreCase("01")&& i == 3){
						debitdata.put("sNo", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")&&i == 4){
						debitdata.put("description", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")  &&data[2].equalsIgnoreCase("01")&& i == 5){
						debitdata.put("billType", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")  &&data[2].equalsIgnoreCase("01")&& i == 6){
						debitdata.put("amountExSt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
				     } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")  &&data[2].equalsIgnoreCase("01")&& i == 7){
						debitdata.put("amountSt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1D")  &&data[2].equalsIgnoreCase("01")&& i == 8){
					  debitdata.put("amountInclSt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 }
					 
					 if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1T")  && data[2].equalsIgnoreCase("01")&& i == 4){
						debitdata.put("totalAmtExSt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1T")  && data[2].equalsIgnoreCase("01")&& i == 5){
						debitdata.put("totalAmtSt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 } if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1T")  && data[2].equalsIgnoreCase("01")&& i == 6){
						debitdata.put("totalAmountInclSt", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 }
					  if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1S")  && data[2].equalsIgnoreCase("01")&& i == 3){
						debitdata.put("reasonOfbilling", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					 }
					  if(data[0].equalsIgnoreCase("0001") && data[1].equalsIgnoreCase("1R")  && data[2].equalsIgnoreCase("01")&& i == 3){
						debitdata.put("email", data[i] != null && data[i].length()>0 ?data[i].trim() : "");
					}
                 
	    	}
		   if(add) {
			   debitRS.put(currentLint, debitdata);
			   currentLint++;
			   listdebitRSdetails.put(pdfGencount, debitRS);
		   }
		}
	}
		
	}catch(Exception e) {
		System.out.println("[DebitService.getDebitDetails()]  Exception : "+e.toString());
	}
	
		return listdebitRSdetails;
	}
	
	
	
	




	public void startBatch() {
		System.out.println("Starting thread ");
		
		if (t == null) {
			t = new Thread(this);
			t.start();
		}
	}
 public static void main(String args[]) {
	 DebitService debitdata=new DebitService();
	 debitdata.startBatch();
	 System.out.println("startedd.....");
 }
}