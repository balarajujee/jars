package com.aia.g400.model;

public class Invoice {

	private String companyName;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String addressLine5;
	private String billNum;
	private String dateOfIssue;
	private String billingPeriod;
	private String paymentDueDate;
	private String policyHolder;
	private String subsidiary;
	private String policyNum;
	private String policyPeriod;
	private String poNum;
	private String description;
	private String billType;
	private String amountExSt;
	private String amountSt;
	private String amountInclSt;
	private String totalAmtExSt;
	private String totalAmtSt;
	private String totalAmountInclSt;
	private String reasonOfbilling;
	private String email;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getAddressLine4() {
		return addressLine4;
	}
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}
	public String getAddressLine5() {
		return addressLine5;
	}
	public void setAddressLine5(String addressLine5) {
		this.addressLine5 = addressLine5;
	}
	public String getBillNum() {
		return billNum;
	}
	public void setBillNum(String billNum) {
		this.billNum = billNum;
	}
	public String getDateOfIssue() {
		return dateOfIssue;
	}
	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	public String getBillingPeriod() {
		return billingPeriod;
	}
	public void setBillingPeriod(String billingPeriod) {
		this.billingPeriod = billingPeriod;
	}
	public String getPaymentDueDate() {
		return paymentDueDate;
	}
	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}
	public String getPolicyHolder() {
		return policyHolder;
	}
	public void setPolicyHolder(String policyHolder) {
		this.policyHolder = policyHolder;
	}
	public String getSubsidiary() {
		return subsidiary;
	}
	public void setSubsidiary(String subsidiary) {
		this.subsidiary = subsidiary;
	}
	public String getPolicyNum() {
		return policyNum;
	}
	public void setPolicyNum(String policyNum) {
		this.policyNum = policyNum;
	}
	public String getPolicyPeriod() {
		return policyPeriod;
	}
	public void setPolicyPeriod(String policyPeriod) {
		this.policyPeriod = policyPeriod;
	}
	public String getPoNum() {
		return poNum;
	}
	public void setPoNum(String poNum) {
		this.poNum = poNum;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public String getAmountExSt() {
		return amountExSt;
	}
	public void setAmountExSt(String amountExSt) {
		this.amountExSt = amountExSt;
	}
	public String getAmountSt() {
		return amountSt;
	}
	public void setAmountSt(String amountSt) {
		this.amountSt = amountSt;
	}
	public String getAmountInclSt() {
		return amountInclSt;
	}
	public void setAmountInclSt(String amountInclSt) {
		this.amountInclSt = amountInclSt;
	}
	public String getTotalAmtExSt() {
		return totalAmtExSt;
	}
	public void setTotalAmtExSt(String totalAmtExSt) {
		this.totalAmtExSt = totalAmtExSt;
	}
	public String getTotalAmtSt() {
		return totalAmtSt;
	}
	public void setTotalAmtSt(String totalAmtSt) {
		this.totalAmtSt = totalAmtSt;
	}
	public String getTotalAmountInclSt() {
		return totalAmountInclSt;
	}
	public void setTotalAmountInclSt(String totalAmountInclSt) {
		this.totalAmountInclSt = totalAmountInclSt;
	}
	public String getReasonOfbilling() {
		return reasonOfbilling;
	}
	public void setReasonOfbilling(String reasonOfbilling) {
		this.reasonOfbilling = reasonOfbilling;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}