package com.aia.g400.utility;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.aia.g400.model.MemberClimeDetails;

public class MemberClimeExcelUtil {

	
	
public static void createExcel(List<MemberClimeDetails> data, String excelFilePath) {
	    
	    Workbook workbook= getWorkbook(excelFilePath);
	    Sheet sheet = workbook.createSheet("MemberClimeDetails");
	    createHeaderRow(sheet); 
	    int rowCount = 1;
	 
	    for (MemberClimeDetails memberclimedata : data) {
	        Row row = sheet.createRow(rowCount++);
	        createDataRow(memberclimedata,row);
	    }
	 
	    FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(excelFilePath);
			 workbook.write(outputStream);
		        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				outputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	       
	}
private static Workbook getWorkbook(String excelFilePath) {
    Workbook workbook = null;
    if (excelFilePath.endsWith("xlsx")) {
        workbook = new XSSFWorkbook();
    } else if (excelFilePath.endsWith("xls")) {
        workbook = new HSSFWorkbook();
    } else {
        throw new IllegalArgumentException("The specified file is not Excel file");
    }
    return workbook;
}
 
private static void createHeaderRow(Sheet sheet) {
	 
    CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
    Font font = sheet.getWorkbook().createFont();
    font.setBold(true);
    font.setFontHeightInPoints((short) 12);
    cellStyle.setFont(font);
 
    Row row = sheet.createRow(0);
    Cell cell0=row.createCell(0);
    cell0.setCellStyle(cellStyle);
    cell0.setCellValue("POLICY NUMBER");
    
    Cell cell1 = row.createCell(1);
    cell1.setCellStyle(cellStyle);
    cell1.setCellValue("COMPANY NAME");
    
    Cell cell2 = row.createCell(2);
    cell2.setCellStyle(cellStyle);
    cell2.setCellValue("BILLING MONTH");
    

    Cell cell3 = row.createCell(3);
    cell3.setCellStyle(cellStyle);
    cell3.setCellValue("BILL NUMBER");
    
    Cell cell4 = row.createCell(4);
    cell4.setCellStyle(cellStyle);
    cell4.setCellValue("CLAIM NO.");
    
    Cell cell5 = row.createCell(5);
    cell5.setCellStyle(cellStyle);
    cell5.setCellValue("EMPLOYEE NAME");
    
    Cell cell6 = row.createCell(6);
    cell6.setCellStyle(cellStyle);
    cell6.setCellValue("EMPLOYEE IC/PASSPORT NO");
    
    Cell cell7 = row.createCell(7);
    cell7.setCellStyle(cellStyle);
    cell7.setCellValue("EMPLOYEE ID");
    
    Cell cell8 = row.createCell(8);
    cell8.setCellStyle(cellStyle);
    cell8.setCellValue("CLAIMANT NAME");
    
    Cell cell9 = row.createCell(9);
    cell9.setCellStyle(cellStyle);
    cell9.setCellValue("MEMBERSH");
    
    Cell cell_10 = row.createCell(10);
    cell_10.setCellStyle(cellStyle);
    cell_10.setCellValue("RELATIONSHIP");
    
    Cell cell_11 = row.createCell(11);
    cell_11.setCellStyle(cellStyle);
    cell_11.setCellValue("PLAN NO.");
    
    Cell cell_12 = row.createCell(12);
    cell_12.setCellStyle(cellStyle);
    cell_12.setCellValue("PLAN DESCRIPTION");
    
    Cell cell_13 = row.createCell(13);
    cell_13.setCellStyle(cellStyle);
    cell_13.setCellValue("PRODUCT CODE");
    
    Cell cell_14 = row.createCell(14);
    cell_14.setCellStyle(cellStyle);
    cell_14.setCellValue("PRODUCT DESCRIPTION");
    
    Cell cell_15 = row.createCell(15);
    cell_15.setCellStyle(cellStyle);
    cell_15.setCellValue("BRANCH");
    
    Cell cell_16 = row.createCell(16);
    cell_16.setCellStyle(cellStyle);
    cell_16.setCellValue("COST CENTRE");
    
    Cell cell_17 = row.createCell(17);
    cell_17.setCellStyle(cellStyle);
    cell_17.setCellValue("VISIT DATE");
    
    Cell cell_18 = row.createCell(18);
    cell_18.setCellStyle(cellStyle);
    cell_18.setCellValue("PROVIDER"); 
   
    Cell cell_19 = row.createCell(19);
    cell_19.setCellStyle(cellStyle);
    cell_19.setCellValue("CLAIM TYPE"); 
    
    Cell cell_20 = row.createCell(20);
    cell_20.setCellStyle(cellStyle);
    cell_20.setCellValue("ASO BILLED AMOUNT(RM)");
    
    Cell cell_21 = row.createCell(21);
    cell_21.setCellStyle(cellStyle);
    cell_21.setCellValue("ASO CLAIMS PAID(RM)"); 
    
    Cell cell_22 = row.createCell(22);
    cell_22.setCellStyle(cellStyle);
    cell_22.setCellValue("CLAIM PAID"); 
}

private static void createDataRow(MemberClimeDetails memberclimedata,Row row) {

		 row.createCell(0).setCellValue(memberclimedata.getPolicyNum());
		 row.createCell(1).setCellValue(memberclimedata.getCompanyName());
		 row.createCell(2).setCellValue(memberclimedata.getBillingMonth());
		 row.createCell(3).setCellValue(memberclimedata.getBillNum());
		 row.createCell(4).setCellValue(memberclimedata.getClaimNum());
		 row.createCell(5).setCellValue(memberclimedata.getEmpName());
		 row.createCell(6).setCellValue(memberclimedata.getEmpIcOrPsprtNUm());
		 row.createCell(7).setCellValue(memberclimedata.getEmpId());
		 row.createCell(8).setCellValue(memberclimedata.getClaimantName());
		 row.createCell(9).setCellValue(memberclimedata.getMembersh());
		
		 row.createCell(10).setCellValue(memberclimedata.getRelationShip());
		 row.createCell(11).setCellValue(memberclimedata.getPlanNum());
		 row.createCell(12).setCellValue(memberclimedata.getPlandescr());
		 row.createCell(13).setCellValue(memberclimedata.getProdCode());
		 row.createCell(14).setCellValue(memberclimedata.getProdDescr());
		 row.createCell(15).setCellValue(memberclimedata.getBranch());
		 row.createCell(16).setCellValue(memberclimedata.getCostCentre());
		 row.createCell(17).setCellValue(memberclimedata.getVisitDate());
		 row.createCell(18).setCellValue(memberclimedata.getProvider());
		 row.createCell(19).setCellValue(memberclimedata.getClaimeType());
		 
		 row.createCell(20).setCellValue(memberclimedata.getAsoBillAmt());
		 row.createCell(21).setCellValue(memberclimedata.getAsoclaimsPaid());
		 row.createCell(22).setCellValue(memberclimedata.getClaimPaid());
   }

}
